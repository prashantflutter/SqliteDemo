Please place here anything you'd like to convey about your solution now and what you might have missed out or would like to implement at a later date to improve.

e.g

*During this project I kept the API responses as pure Map objects. With more time, I would have implemented api model objects to show and correctly parse the JSON data into more appropriate data types once.*

*While calling an API directly from a widget might be okay for a small project, I would consider going forward, moving networking calls out of the UI to have a separation of concerns and more testable code*