import 'dart:io';

import 'package:collection/collection.dart' show IterableExtension;
import 'package:mock_server/mock_server.dart';
import 'package:mock_server/src/asset_loader/mock_server_asset_loader.dart';
import 'package:mock_server/src/certificates.dart';
import 'package:mock_server/src/handlers/mock_request_handler.dart';
import 'package:mock_server/src/handlers/payments_handler.dart';
import 'package:shelf/shelf.dart' as shelf;
import 'package:shelf/shelf_io.dart' as io;

/// Mock server
class MockServer {
  MockServer({
    this.assetLoader = const DefaultAssetLoader(),
    this.port = 8085,
  });

  HttpServer? server;
  MockServerAssetLoader assetLoader;
  final int port;

  int secondsToDelayLoad = 1;

  final List<MockRequestHandler> handlers = [
    PaymentsHandler(),
  ];

  Future<void> start({int? secondsToLoad}) async {
    globalAssetLoader = assetLoader;
    if (secondsToLoad != null) {
      secondsToDelayLoad = secondsToLoad;
    }

    final handler = const shelf.Pipeline()
        .addMiddleware(shelf.logRequests())
        .addHandler(_requestsHandler);

    final context = SecurityContext()
      ..useCertificateChainBytes(Certificates.certificate)
      ..usePrivateKeyBytes(Certificates.key, password: Certificates.aveosoft);

    await close(true);

    server = await io.serve(handler, InternetAddress.loopbackIPv4, port,
        securityContext: context);
  }

  Future<shelf.Response> _requestsHandler(shelf.Request request) async {
    if (request.method == 'OPTIONS') {
      return shelf.Response.ok(
        null,
        headers: {
          'Access-Control-Allow-Headers':
              request.headers['Access-Control-Request-Headers']!,
          'Access-Control-Allow-Origin': request.headers['origin']!,
          'Access-Control-Allow-Methods':
              'OPTIONS, GET, HEAD, POST, PATCH, DELETE',
          'Access-Control-Max-Age': '30',
        },
      );
    }

    await Future.delayed(Duration(seconds: secondsToDelayLoad));

    final requestHandler = handlers.firstWhereOrNull(
      (handler) => handler.canHandle(request),
    );

    if (requestHandler == null) {
      return shelf.Response.notFound(null);
    }

    return requestHandler.handle(request);
  }

  Future<void> close(bool force) async {
    if (server != null) {
      await server!.close(force: force);
      server = null;
    }
  }
}
