import 'package:shelf/shelf.dart' as shelf;

//DONT_GENERATE_TEST_FILE
abstract class MockRequestHandler {
  bool canHandle(shelf.Request request);

  Future<shelf.Response> handle(shelf.Request request);
}
