import 'dart:io';
import 'dart:typed_data';

abstract class MockServerAssetLoader {
  Future<Uint8List> dataForAsset(String assetPath);
  Future<String> loadUserResponse(String path);
}

class DefaultAssetLoader implements MockServerAssetLoader {
  const DefaultAssetLoader();

  @override
  Future<Uint8List> dataForAsset(String assetPath) =>
      File(assetPath).readAsBytes();

  @override
  Future<String> loadUserResponse(String path) {
    return File('lib/assets/responses/user/' + path).readAsString();
  }
}

MockServerAssetLoader? globalAssetLoader;
