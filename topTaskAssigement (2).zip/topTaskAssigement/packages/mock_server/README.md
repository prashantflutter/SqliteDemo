# Aveosoft mock server

## Introduction

This project is a Flutter package that acts as a MockServer. It's based on shelf and dart.http_server.

## HTTPS certificate

The content is served under https using a self signed certificate.

The self signed certificate was generated using openssl with this command:

    openssl req -x509 -newkey rsa:4096 -keyout key.pem -out cert.pem -days 3650

cert and key PEM files are located in mock_server/lib/src/certificates.dart as byte[]. The key pass phrase is 'aveosoft'.
