import 'package:flutter/services.dart';
import 'package:mock_server/mock_server.dart';

class MockServerFlutterAssetLoader implements MockServerAssetLoader {
  @override
  Future<Uint8List> dataForAsset(String assetPath) async {
    final data = await rootBundle.load(assetPath);

    return data.buffer.asUint8List();
  }

  @override
  Future<String> loadUserResponse(String path) async {
    return await rootBundle
        .loadString('packages/mock_server/assets/responses/user/$path');
  }
}
