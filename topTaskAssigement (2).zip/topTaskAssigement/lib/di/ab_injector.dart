import 'package:aveosoft_test/api.dart';
import 'package:aveosoft_test/utils/services/network_client.dart';
import 'package:get_it/get_it.dart';

class ABInjector {
  static final ABInjector _instance = ABInjector();

  /// access to the Singleton instance of GetIt
  static ABInjector get instance => _instance;

  /// Short form to access the instance of GetIt
  static ABInjector get I => _instance;

  late GetIt gi;

  T call<T extends Object>({String? instanceName, param1, param2}) {
    return gi.call<T>(
      instanceName: instanceName,
      param1: param1,
      param2: param2,
    );
  }

  Future<void> bootstrap({GetIt? getIt}) async {
    gi = getIt ?? GetIt.I;

    await gi.reset();

    gi.registerFactory<Api>(
      () => Api(
        NetworkClient(
          baseUrl: 'https://127.0.0.1:8085',
        ).dio,
      ),
    );
  }
}
