class TransactionsState {
  const TransactionsState({
    this.isLoading = false,
    this.errorLoading = false,
  });

  final bool isLoading;
  final bool errorLoading;

  TransactionsState copyWith({
    bool? isLoading,
    bool? errorLoading,
  }) =>
      TransactionsState(
        isLoading: isLoading ?? this.isLoading,
        errorLoading: errorLoading ?? this.errorLoading,
      );
}
