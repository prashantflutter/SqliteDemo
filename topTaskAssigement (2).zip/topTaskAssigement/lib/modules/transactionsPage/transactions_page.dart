
import 'dart:math';

import 'package:aveosoft_test/api.dart';
import 'package:aveosoft_test/di/ab_injector.dart';
import 'package:flutter/material.dart';

import '../../Model/TransactionDataModel.dart';


class TransactionsPage extends StatefulWidget {
  const TransactionsPage({super.key});

  @override
  State<TransactionsPage> createState() => _TransactionsPageState();
}

class _TransactionsPageState extends State<TransactionsPage> {


  Map<String, dynamic> transactionData = {};
  List<TransactionDataModel> transactionList = [];
  ScrollController scrollController = ScrollController();
  ValueNotifier<int> listChange = ValueNotifier(0);
  bool isLoading = false;
  int page = 1;
  @override
  void initState() {
    super.initState();
    init();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return SizedBox(
      width: double.infinity,
      height: double.infinity,
      child: RefreshIndicator(
        displacement: size.height*0.2,
        color: Colors.deepPurple,
        strokeWidth: 2,
        onRefresh: (){
          return Future<void>.delayed(const Duration(seconds: 2)).whenComplete(() async{
            init();
          });
        },
        child: ValueListenableBuilder(
          valueListenable: listChange,
          builder: (context, value, child) {
            return  Scaffold(
              appBar: AppBar(
                backgroundColor: Colors.deepPurple,
                title: Text('Transactions',style: CustomStyle.MyTextStyle(textColor: Colors.white,fontSize: 20),),
                centerTitle: true,
              ),
              body: transactionList.isNotEmpty ?ListView.builder(
                  itemCount: transactionList.length,
                  controller: scrollController,
                  itemBuilder: (context,index){
                    debugPrint("data length == ${transactionList.length}");
                    final mIndex = transactionList[index];
                    var no = index+1;
                    var iconType  = mIndex.iconType;
                    return Card(
                      color: Colors.white,
                      elevation: 1,
                      shadowColor: Colors.deepPurple,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.zero
                      ),
                      margin: EdgeInsets.symmetric(vertical: size.width*0.020,horizontal: size.width*0.030),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 15,vertical: 5),
                        child:  Column(
                          children: [

                            Row(
                              children: [
                                SizedBox(width: size.height*0.094,),
                                mIndex.counterpartyName != ''?Text(mIndex.transactionReference.toString().trim(),style: CustomStyle.MyTextStyle(textColor: Colors.black,fontSize: 14,fontWeight: FontWeight.bold),):
                                Text(mIndex.counterpartyName.toString(),style: CustomStyle.MyTextStyle(textColor: Colors.black,fontSize: 14,fontWeight: FontWeight.bold),)
                              ],
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                Icon(Icons.currency_rupee,color: Colors.deepPurple,size: size.height*0.045,),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    TitleWithData(title: 'No.', data: no.toString()),
                                    TitleWithData(title: 'Debit Type', data: mIndex.debitCreditCode.toString()),
                                    TitleWithData(title: 'Bal', data: mIndex.balance.toString()),
                                  ],
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    TitleWithData(title: 'Amount', data: mIndex.amount.toString()),
                                    TitleWithData(title: 'Type', data: iconType == ''?'N/A':iconType == 'CARD_BACKWARDS_ARROW'?'CARD BACKWARDS':mIndex.iconType?.replaceAll('_', ' ')??'N/A'),
                                    TitleWithData(title: 'Avl Bal', data: mIndex.availableBalance.toString())
                                  ],
                                ),
                              ],
                            ),

                          ],
                        ),
                      ),
                    );
                  }) : Center(child: CircularProgressIndicator(color: Colors.deepPurple,)),
            );
          }
        ),
      ),
    );

  }


  Widget TitleWithData({required String title,required String data}){
    return Padding(
      padding: EdgeInsets.only(bottom: 2),
      child: Row(
        children: [
          Text('$title :',style: CustomStyle.MyTextStyle(textColor: Colors.black54,fontSize: 14),),
          Padding(
            padding: EdgeInsets.only(left: 5),
            child: Text(data,overflow: TextOverflow.ellipsis,style: CustomStyle.MyTextStyle(textColor: Colors.black,fontSize: 14,fontWeight: FontWeight.bold),),
          ),
        ],
      ),
    );
  }

  void init() async {
    transactionData = await ABInjector.I<Api>().getPaymentTransactions();

    transactionList.clear();
    for(var i in transactionData['transactions']){
      transactionList.add(TransactionDataModel.fromJson(i));

    }
    debugPrint('====Data === ${transactionList.length}');
    scrollController.addListener(() async {

      if (scrollController.position.maxScrollExtent == scrollController.position.pixels)  {
          page++;
          isLoading = true;
          if(page == 2){
            Map<String, dynamic> newData = await ABInjector.I<Api>().getPaymentTransactions(pageNumber: page).whenComplete(() => isLoading = false);
            for(var i in newData['transactions']){
              transactionList.add(TransactionDataModel.fromJson(i));
            }
            debugPrint('====Data Length === ${transactionList.length}');
            listChange.value = Random().nextInt(999999);
          }
      }
    });
    listChange.value = Random().nextInt(999999);
  }
}

class CustomStyle{
  static MyTextStyle({Color textColor = Colors.black,FontWeight fontWeight = FontWeight.w600,double fontSize = 18}){
   return TextStyle(color: textColor,fontWeight: fontWeight,fontSize: fontSize);
  }
}
