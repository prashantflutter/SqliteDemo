import 'package:aveosoft_test/modules/payeesPage/payees_page.dart';
import 'package:aveosoft_test/modules/pendingPaymentsPage/pending_payments_page.dart';
import 'package:aveosoft_test/modules/transactionsPage/transactions_page.dart';
import 'package:flutter/material.dart';

class AccountHomePage extends StatefulWidget {
  const AccountHomePage({super.key});

  @override
  State<AccountHomePage> createState() => _AccountHomePageState();
}

class _AccountHomePageState extends State<AccountHomePage> {
  int _selectedTab = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: _pagesStack(),
      bottomNavigationBar: _buildBottomNavigationBar(),
    );
  }

  IndexedStack _pagesStack() => IndexedStack(
        index: _selectedTab,
        children: const [
          TransactionsPage(),
          PayeesPage(),
          PendingPaymentsPage(),
        ],
      );

  Widget _buildBottomNavigationBar() {
    return BottomNavigationBar(
      type: BottomNavigationBarType.fixed,
      items: const [
        BottomNavigationBarItem(
          icon: Icon(Icons.money),
          label: 'Transactions',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.person),
          label: 'Payees',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.calendar_month),
          label: 'Pending Payments',
        ),
      ],
      currentIndex: _selectedTab,
      onTap: (int index) {
        setState(() {
          _selectedTab = index;
        });
      },
    );
  }
}
