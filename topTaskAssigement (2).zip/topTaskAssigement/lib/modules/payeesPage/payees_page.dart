// import 'package:aveosoft_test/api.dart';
// import 'package:aveosoft_test/di/ab_injector.dart';
import 'package:flutter/material.dart';

class PayeesPage extends StatefulWidget {
  const PayeesPage({super.key});

  @override
  State<PayeesPage> createState() => _PayeesPageState();
}

class _PayeesPageState extends State<PayeesPage> {
  @override
  void initState() {
    super.initState();

    // ABInjector.I<Api>().getPayees();
  }

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text('Payees'),
    );
  }
}
