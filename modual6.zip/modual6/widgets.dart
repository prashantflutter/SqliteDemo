import 'package:flutter/material.dart';
import 'AppConstant/appColors.dart';

class MyBottomSheetContent extends StatelessWidget {
  final String title;
  final bool isSuc;
  final BuildContext parentContext;

  MyBottomSheetContent(this.parentContext, this.title, {this.isSuc = false});

  @override
  Widget build(BuildContext context) {

    Future.delayed(Duration(seconds: 2), () {
      Navigator.pop(parentContext);
    });

    return Container(
      width: double.infinity,
      height: 120,
      color: primeColor,
      child: Row(
        children: [
          SizedBox(width: 20,),
          isSuc?Icon(Icons.done,size: 50,color: Colors.white,):
          Icon(Icons.report,size: 50,color: Colors.white,),
          SizedBox(width: 20,),
          Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 20,),
              isSuc== false?Text('Uh oh!',style: TextStyle(color: Colors.white,fontSize: 30,),):
              Text('Congratulations...',style: TextStyle(color: Colors.white,fontSize: 30,),),
              Text(title,style: TextStyle(color: Colors.white,fontSize: 16,),),
            ],
          )
        ],
      ),
    );
  }
}

Widget CustomButton({required void Function()? onPressed,bool isRound = true,String text = ''}){
  return Container(
    width: 260,
    height: 55,
    child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
            backgroundColor: isRound?primeColor:null,
            side: isRound?null:BorderSide(
              color: primeColor,
            )
        ),
        child: Text(text,style: TextStyle(color: isRound?Colors.white:primeColor,),)),
  );
}


Widget CustomTextField({required TextEditingController controller,required String hintText,Widget? prefixIcon}){
  return TextFormField(
    controller: controller,
    cursorColor: primeColor,
    decoration: InputDecoration(
      hintText: '  $hintText',
      hintStyle: TextStyle(color: Colors.black26),
      prefixIcon: prefixIcon,
      filled: true,
      fillColor: Colors.white,
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(50),
        borderSide: BorderSide(color: Colors.black.withOpacity(0.1),width: 0.2),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(50),
        borderSide: BorderSide(color: Colors.white),
      ),
    ),
  );
}

