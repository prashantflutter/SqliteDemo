import 'package:flutter/material.dart';

import '../AppConstant/appColors.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Chatter',style: TextStyle(color:primeColor,fontSize: 20),),
        iconTheme:  IconThemeData(color: primeColor),
        actions: [
          Icon(Icons.more_vert)
        ],
      ),
      body: Container(
        width: double.infinity,
        child: SingleChildScrollView(
          child: Column(
            children: [
              Column(
                children: [
                  SizedBox(height: 250,),
                  ChatBox(data: 'Hallo, Stranger!', userName: 'Test USer'),
                  ChatBox(data: 'This is a simple demonstration', userName: 'prashant',isLeft: false),
                  ChatBox(data: 'Did you notice these seamilees animation?', userName: 'Test USer'),
                  ChatBox(data: 'You mean like when i am typing like this...?', userName: 'prashant',isLeft: false),
                  ChatBox(data: 'Hallo, Stranger!', userName: 'Test USer'),
                  ChatBox(data: 'This is a simple demonstration', userName: 'prashant',isLeft: false),

                ],
              ),
            ],
          ),
        ),
      ),

    );
  }

  Widget ChatBox({bool isLeft = true,required String data,required String userName}){
    return Container(
      width: double.infinity,
      child: Column(
        crossAxisAlignment: isLeft?CrossAxisAlignment.start:CrossAxisAlignment.end,
        mainAxisAlignment: isLeft?MainAxisAlignment.start:MainAxisAlignment.end,
        children: [
          Container(width: double.infinity,margin: isLeft?EdgeInsets.only(left: 10):EdgeInsets.only(right: 10),
              child: Text(userName,textAlign: isLeft?TextAlign.start:TextAlign.end,)),
          Container(
            width: 280,
            alignment: isLeft?Alignment.centerLeft:Alignment.centerRight,
            padding: EdgeInsets.symmetric(horizontal: 15,vertical: 15),
            margin: isLeft?EdgeInsets.only(left: 10):EdgeInsets.only(right: 10),
            decoration: BoxDecoration(
                color: isLeft?Colors.white:Colors.blue,
                borderRadius: BorderRadius.only(
                  topLeft: isLeft?Radius.circular(0):Radius.circular(50),
                  topRight: isLeft?Radius.circular(50):Radius.circular(0),
                  bottomLeft: Radius.circular(50),
                  bottomRight: Radius.circular(50),
                ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.2),
                  blurRadius: 2,
                  offset: Offset(0, 4)
                )
              ]
            ),
            child: Text(data,textAlign: isLeft?TextAlign.start:TextAlign.end,style: TextStyle(color: isLeft?Colors.blue:Colors.white,fontSize: 16),),

          )
        ],
      ),
    );
  }
}
