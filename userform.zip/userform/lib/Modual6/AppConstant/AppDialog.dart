import 'package:flutter/material.dart';
import 'appColors.dart';

class MyBottomSheetContent extends StatelessWidget {
  final String? description;
  final bool? isDone;
  final BuildContext parentContext;

  MyBottomSheetContent(this.parentContext, this.description, this.isDone);

  @override
  Widget build(BuildContext context) {


    Future.delayed(Duration(seconds: 2), () {
      Navigator.pop(parentContext);
    });

    return Container(
      width: double.infinity,
      height: 100,
      color: primeColor,
      child: Row(
        children: [
          SizedBox(width: 20,),
          isDone == true? Icon(Icons.done,size: 35,color: Colors.white,):Icon(Icons.report,size: 50,color: Colors.white,),
          SizedBox(width: 20,),
          Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 15,),
              isDone == true? Text('Congratulations 🥳🥳🥳',style: TextStyle(color: Colors.white,fontSize: 25,),):Text('Uh oh!',style: TextStyle(color: Colors.white,fontSize: 25,),),
              Text(description!.replaceAll(RegExp('[_,-]'), " "),style: TextStyle(color: Colors.white,fontSize: 16,),),
            ],
          )
        ],
      ),
    );
  }
}