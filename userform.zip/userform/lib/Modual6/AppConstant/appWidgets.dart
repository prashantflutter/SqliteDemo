import 'package:flutter/material.dart';
import 'AppDialog.dart';
import 'appColors.dart';

Widget CustomButton({required void Function()? onPressed,bool isRound = true,String text = ''}){
  return Container(
    width: 260,
    height: 55,
    child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
            backgroundColor: isRound?primeColor:Colors.white,
            side: isRound?null:BorderSide(
              color: primeColor,
            )
        ),
        child: Text(text,style: TextStyle(color: isRound?Colors.white:primeColor,),)),
  );
}


Widget CustomTextField({required TextEditingController controller,required String hintText,Widget? prefixIcon,Widget? suffixIcon,bool obscureText = false}){
  return Padding(
    padding: const EdgeInsets.symmetric(horizontal: 30,vertical: 8),
    child: TextFormField(
      controller: controller,
      cursorColor: primeColor,
      obscureText: obscureText,
      decoration: InputDecoration(
        hintText: '$hintText',
        hintStyle: TextStyle(color: Colors.black26),
        prefixIcon: Padding(
          padding: EdgeInsets.only(left: 20,right: 10),
          child: prefixIcon,
        ),
        suffixIcon: Padding(
          padding: EdgeInsets.only(right: 15),
          child: suffixIcon,
        ),
        filled: true,
        fillColor: Colors.white,
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(50),
          borderSide: BorderSide(color: Colors.black.withOpacity(0.1),width: 0.2),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(50),
          borderSide: BorderSide(color: Colors.white),
        ),
      ),
    ),
  );
}



Future MyDialog(BuildContext context,{required String description,bool isDone = false}){
  return  showModalBottomSheet(
      context: context,
      builder: (context){
        return MyBottomSheetContent(context,description, isDone);
      }).then((value) {print('Bottom sheet closed with result: $value');
  });
}
