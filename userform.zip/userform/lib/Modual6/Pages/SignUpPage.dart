import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:userform/Modual6/Pages/LoginPage.dart';

import '../AppConstant/appColors.dart';
import '../AppConstant/appWidgets.dart';


class SignUpPage extends StatefulWidget {
  const SignUpPage({super.key});

  @override
  State<SignUpPage> createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {

  TextEditingController nameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController cPasswordController = TextEditingController();

  bool isPassword = true;
  bool iscPassword = true;

  ValueNotifier changeValue = ValueNotifier<int>(0);

  void createUser()async{
    String name = nameController.text.trim();
    String email = emailController.text.trim();
    String password = passwordController.text.trim();
    String cPassword = cPasswordController.text.trim();
    if(name.isEmpty || email.isEmpty || password.isEmpty || cPassword.isEmpty){
      MyDialog(context, description: 'please fill all details!');
    }else if(password != cPassword){
      MyDialog(context, description: 'password are do not match!');
    }else{
      try{
        UserCredential userCredential = await FirebaseAuth.instance.createUserWithEmailAndPassword(email: email, password: password);
        if(userCredential.user != null){
          Navigator.push(context, MaterialPageRoute(builder: (context) => LoginPage()));
          MyDialog(context, description: 'Successfully signup...',isDone: true);
        }
      }on FirebaseException catch(ex){
        debugPrint('Error : ${ex.code.toString()}');
        MyDialog(context, description: 'please ${ex.code.toString()}!');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      body: Container(
        width: size.width,
        child: ValueListenableBuilder(
          valueListenable: changeValue,
          builder: (context,value,child) {
            return SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(height: size.height*0.1,),
                  Icon(Icons.chat,size: size.height*0.1,color: primeColor,),
                  Padding(
                    padding: EdgeInsets.only(top: 10),
                    child: Text('Chatter',style: TextStyle(color: primeColor,fontSize: 20,fontWeight: FontWeight.bold),),
                  ),
                  SizedBox(height: size.height*0.02,),
                  CustomTextField(
                    controller: nameController,
                    hintText: 'Enter Name',
                    prefixIcon: Icon(Icons.account_circle,color: primeColor,),
                  ),
                  CustomTextField(
                    controller: emailController,
                    hintText: 'Email',
                    prefixIcon: Icon(Icons.email,color: primeColor,),
                  ),
                  CustomTextField(
                    controller: passwordController,
                    hintText: 'Enter Password',
                    obscureText: isPassword,
                    prefixIcon: Icon(Icons.password,color: primeColor,),
                    suffixIcon:IconButton(onPressed: (){
                      isPassword = !isPassword;
                      changeValue.value++;
                    }, icon:  Icon(isPassword?Icons.visibility_off:Icons.visibility,color: primeColor,),
                    ),
                  ),
                  CustomTextField(
                    controller: cPasswordController,
                    hintText: 'Enter Confirm Password',
                    obscureText: iscPassword,
                    prefixIcon: Icon(Icons.lock,color: primeColor,),
                    suffixIcon:IconButton(onPressed: (){
                      iscPassword = !iscPassword;
                      changeValue.value++;
                    }, icon:  Icon(iscPassword?Icons.visibility_off:Icons.visibility,color: primeColor,),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 30),
                    child: CustomButton(onPressed: (){
                      createUser();
                    },text: 'SUBMIT'),
                  ),
                ],
              ),
            );
          }
        ),
      ),
    );
  }
}
