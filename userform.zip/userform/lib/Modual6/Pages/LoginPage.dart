import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:userform/Modual6/Pages/SignUpPage.dart';
import '../AppConstant/appColors.dart';
import '../AppConstant/appWidgets.dart';
import 'ChatHomePage.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {

  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  void login()async{
    String email = emailController.text.trim();
    String password = passwordController.text.trim();
    if(email.isEmpty || password.isEmpty){
      MyDialog(context, description: 'please fill email and password!');
    }else{
      try{
        UserCredential userCredential = await FirebaseAuth.instance.signInWithEmailAndPassword(email: email, password: password);
        if(userCredential.user != null){
          Navigator.popUntil(context, (route) => route.isFirst);
          Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => ChatHomePage()));
          MyDialog(context, description: 'Successfully Login...',isDone: true);
        }
      }on FirebaseException catch(ex){
        debugPrint('Error : ${ex.code.toString()}');
        MyDialog(context, description: 'please ${ex.code.toString()}!');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Container(
        width: double.infinity,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(height: size.height*0.05,),
            Icon(Icons.chat,size: size.height*0.14,color: primeColor,),
            Padding(
              padding: EdgeInsets.only(top: 15),
              child: Text('Chatter',style: TextStyle(color: primeColor,fontSize: 28,fontWeight: FontWeight.bold),),
            ),
            SizedBox(height: size.height*0.05,),
            CustomTextField(
              controller: emailController,
              hintText: 'Email',
              prefixIcon: Icon(Icons.email,color: primeColor,),
            ),
            CustomTextField(
              controller: passwordController,
              hintText: 'Password',
              prefixIcon: Icon(Icons.lock,color: primeColor,),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 30),
              child: CustomButton(onPressed: (){
                login();
              },text: 'LOGIN'),
            ),
            Padding(
              padding:  EdgeInsets.only(top: 10),
              child: InkWell(
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=> SignUpPage()));
                },
                  child: Text('or create an account',style: TextStyle(color: primeColor,fontSize: 16,fontWeight: FontWeight.normal),)),
            ),
            SizedBox(height: size.height*0.1,),
            Text('Made with \u{1F49F} by prashantdeveloper',style: TextStyle(color: primeColor,fontSize: 16,fontWeight: FontWeight.normal),),
          ],
        ),
      ),
    );
  }





}
