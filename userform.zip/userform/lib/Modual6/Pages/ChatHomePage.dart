import 'package:flutter/material.dart';

import '../AppConstant/appColors.dart';


class ChatHomePage extends StatefulWidget {
  const ChatHomePage({super.key});

  @override
  State<ChatHomePage> createState() => _ChatHomePageState();
}

class _ChatHomePageState extends State<ChatHomePage> {

  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();


  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      // resizeToAvoidBottomInset: false,
      appBar: AppBar(
        backgroundColor: primeColor,
        title: Text('Chat Page',style: TextStyle(color: Colors.white),),
      ),
      body: Container(
        width: double.infinity,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(child: Container()),
            Container(
              padding: const EdgeInsets.all(10.0),
              margin: const EdgeInsets.all(10.0),
              decoration: BoxDecoration(
                color: Colors.grey,
                borderRadius: BorderRadius.circular(100)
              ),
              child: Row(
                children: [
                  Flexible(child: TextField(
                    decoration: InputDecoration(
                      hintText: 'Enter Massage...',
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.symmetric(horizontal: 15)
                    ),
                  )),
                  IconButton(onPressed: (){}, icon: Icon(Icons.send,color: primeColor,))
                ],
              ),
            )

          ],
        ),
      ),
    );
  }

  

}
