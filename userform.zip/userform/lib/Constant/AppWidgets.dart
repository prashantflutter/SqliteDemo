import 'package:flutter/material.dart';
import 'package:userform/Constant/AppColors.dart';

ScaffoldFeatureController<SnackBar, SnackBarClosedReason> MyDialog({required BuildContext context, required String title, Color? backgroundColor = Colors.red, IconData? icon}) {
  return ScaffoldMessenger.of(context).showSnackBar(SnackBar(
    content: Row(
      children: [
        Icon(
          icon,
          color: primeWhite,
          size: 25,
        ),
        SizedBox(
          width: 10,
        ),
        Text(
          title,
          style: TextStyle(
            color: primeWhite,
          ),
        ),
      ],
    ),
    backgroundColor: backgroundColor,
  ));
}

Widget MyTextField({required TextEditingController controller, required String labelText, int maxLines = 1, Widget? prefixIcon, Widget? suffixIcon, bool obscureText = false}) {
  return TextFormField(
    cursorColor: primeBlue,
    controller: controller,
    maxLines: maxLines,
    obscureText: obscureText,
    autovalidateMode: AutovalidateMode.onUserInteraction,
    decoration: InputDecoration(
      labelText: '$labelText',
      enabledBorder: OutlineInputBorder(
        borderSide: BorderSide(color: primeBlue),
      ),
      focusedBorder: OutlineInputBorder(
        borderSide: BorderSide(color: primeBlue),
      ),
      prefixIcon: prefixIcon,
      suffixIcon: suffixIcon,
    ),
  );
}
