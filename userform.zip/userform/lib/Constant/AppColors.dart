

import 'package:flutter/material.dart';

const Color primeBlue = Color(0xFF42A5F5);
const Color primeWhite = Color(0xFFFFFFFF);