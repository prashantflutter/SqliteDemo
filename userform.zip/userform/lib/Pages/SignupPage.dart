import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:userform/Constant/AppColors.dart';
import 'package:userform/Constant/AppWidgets.dart';

class SignUpPage extends StatefulWidget {
  const SignUpPage({super.key});

  @override
  State<SignUpPage> createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {

  TextEditingController fNameController = TextEditingController();
  TextEditingController lNameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController cPasswordController = TextEditingController();
  bool isPassword = true;
  bool iscPassword = true;
  String userDP = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTYhTfgUddG9kCfl8uOBVK7Q9_joke2_v1Sqg&usqp=CAU';
  final ValueNotifier<int> isView = ValueNotifier<int>(0);

  void signUp()async{
    String fName = fNameController.text.trim();
    String lName = lNameController.text.trim();
    String email = emailController.text.trim();
    String password = passwordController.text.trim();
    String cPassword = cPasswordController.text.trim();

    if(fName.isEmpty || lName.isEmpty || email.isEmpty || password.isEmpty || cPassword.isEmpty){
      MyDialog(context: context, title: 'Please fill all details!',icon: Icons.error_outline);
    }else if(password != cPassword){
      MyDialog(context: context, title: 'Password is don match!',icon: Icons.error_outline);
    }else{
      try{
        UserCredential userCredential = await FirebaseAuth.instance.createUserWithEmailAndPassword(email: email, password: password);
        if(userCredential.user != null){
          Map<String,dynamic> NewDataUser = {
            'userDP':userDP,
            'fName':fName,
            'lName':lName,
            'email':email,
          };
          FirebaseFirestore.instance.collection('MYDataApp').add(NewDataUser);
          Navigator.popUntil(context, (route) => route.isFirst);
          // Navigator.push(context, MaterialPageRoute(builder: (context)=> LoginPage()));
          MyDialog(context: context, title: 'Successfully signup...',icon: Icons.done,backgroundColor: Colors.green);
        }
      } on FirebaseException catch(ex){
        log(ex.code.toString());
        MyDialog(context: context, title: ex.code.toString(),icon: Icons.error_outline);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: primeBlue,
        title: Text('SignUp Page',style: TextStyle(color: primeWhite),),
      ),
      body: ListView(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: CircleAvatar(
              radius: 50,
              backgroundImage: NetworkImage(userDP),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15,vertical: 5),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SizedBox(
                  width: size.width*0.45,
                  child: MyTextField(controller: fNameController, labelText: 'First Name'),
                ),
                SizedBox(
                  width: size.width*0.45,
                  child: MyTextField(controller: lNameController, labelText: 'Last Name'),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15,vertical: 5),
            child: MyTextField(controller: emailController, labelText: 'Enter Email'),
          ),
          ValueListenableBuilder(
            valueListenable: isView,
            builder: (BuildContext context, int value, Widget? child) {
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15,vertical: 5),
                child: MyTextField(controller: passwordController, labelText: 'Enter Password',
                    obscureText: isPassword,
                    suffixIcon: IconButton(onPressed: (){
                      isPassword = !isPassword;
                      isView.value++;
                    }, icon: Icon(isPassword?Icons.visibility_outlined:Icons.visibility_off_outlined),),),
              );
            },
          ),
          ValueListenableBuilder(
            builder: (context,value,child) {
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15,vertical: 5),
                child: MyTextField(controller: cPasswordController, labelText: 'Enter Confirm Password',
                    obscureText: iscPassword,
                    suffixIcon: IconButton(onPressed: (){
                      iscPassword = !iscPassword;
                      isView.value--;
                    }, icon: Icon(iscPassword?Icons.visibility_outlined:Icons.visibility_off_outlined),)),
              );
            }, valueListenable: isView,
          ),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: CupertinoButton(
              color: primeBlue,
                child: Text('Submit'),
                onPressed: (){
                  signUp();
                }),
          ),
        ],
      ),
    );
  }


}
