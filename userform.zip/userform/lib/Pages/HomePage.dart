import 'package:flutter/material.dart';
import 'package:userform/Constant/AppColors.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: primeBlue,
        title: Text('HomePage',style: TextStyle(color: primeWhite),),
      ),
      body: Column(
        children:[

        ],
      ),
    );
  }
}
