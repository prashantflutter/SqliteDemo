// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:userform/Constant/AppWidgets.dart';
//
// import '../Constant/AppColors.dart';
//
// class LoginPage extends StatefulWidget {
//   const LoginPage({super.key});
//
//   @override
//   State<LoginPage> createState() => _LoginPageState();
// }
//
// class _LoginPageState extends State<LoginPage> {
//
//   TextEditingController emailController = TextEditingController();
//   TextEditingController passwordController = TextEditingController();
//   bool isPassword = true;
//   final ValueNotifier<int> isView = ValueNotifier<int>(0);
//
//   void login()async{
//     String email = emailController.text.trim();
//     String password = passwordController.text.trim();
//
//   }
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         automaticallyImplyLeading: false,
//         backgroundColor: primeBlue,
//         title: Text('Login Page',style: TextStyle(color: primeWhite),),
//       ),
//       body: Column(
//         children: [
//          Padding(
//            padding: const EdgeInsets.symmetric(horizontal: 20,vertical: 10),
//            child: MyTextField(controller: emailController, labelText: 'Enter Email'),
//          ),
//          ValueListenableBuilder(
//            valueListenable: isView,
//            builder: (context,value,child) {
//              return Padding(
//                padding: const EdgeInsets.symmetric(horizontal: 20,vertical: 10),
//                child: MyTextField(controller: passwordController, labelText: 'Enter Password',obscureText: isPassword,
//                suffixIcon: IconButton(onPressed: (){
//                  isPassword = !isPassword;
//                  isView.value++;
//                }, icon: Icon(Icons.visibility_off_outlined,))),
//              );
//            },
//          ),
//           CupertinoButton(
//             color: primeBlue,
//               child: Text('Login'), onPressed: (){
//
//           }),
//         ],
//       ),
//     );
//   }
// }
