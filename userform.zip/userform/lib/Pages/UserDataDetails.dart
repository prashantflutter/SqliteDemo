import 'package:flutter/material.dart';
import 'package:userform/Constant/AppColors.dart';

class UserDataDetailPage extends StatefulWidget {
   UserDataDetailPage({super.key});

  @override
  State<UserDataDetailPage> createState() => _UserDataDetailPageState();
}

class _UserDataDetailPageState extends State<UserDataDetailPage> {
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: primeBlue,
        title: Text('User Data Detail Page',style: TextStyle(color: primeWhite),),
      ),
      body: Column(
        children: [

        ],
      ),
    );
  }
}
