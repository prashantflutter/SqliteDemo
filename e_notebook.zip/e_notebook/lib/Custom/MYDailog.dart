

import 'package:flutter/material.dart';

void MYDialog({required BuildContext context,required void Function()? onPressed}){
  showDialog(
      context: context,
      builder: (context){
    return Dialog(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
           Padding(padding: EdgeInsets.all(10),
           child: Text('Add More Function',style: TextStyle(fontWeight: FontWeight.w600,fontSize: 20),),),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Text('Music/Audio'),
                ElevatedButton(onPressed:onPressed, child: Text('Music add')),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Text('NoteBook'),
                ElevatedButton(onPressed:onPressed, child: Text('NoteBook Add')),
              ],
            ),
          ],
        ),
      ),
    );
  });
}