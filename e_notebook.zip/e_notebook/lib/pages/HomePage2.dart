import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:e_notebook/AppConstant/appColors.dart';
import 'package:e_notebook/pages/ChatPage.dart';
import 'package:e_notebook/widgets.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'LoginPage.dart';

class HomePage2 extends StatefulWidget {
  const HomePage2({super.key});

  @override
  State<HomePage2> createState() => _HomePage2State();
}

class _HomePage2State extends State<HomePage2> {

  final FirebaseFirestore fireStore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  var senderName;
  void signOut(){
    showModalBottomSheet(context: context, builder: (context) {
      return LogoutDialog(
          context,
          'Are you sure want to logout?',
          sub1: 'Yes', 
          onPressed1: (){
            FirebaseAuth.instance.signOut();
            Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => LoginPage()));
          },
          sub2: 'No',
      onPressed2: ()=> Navigator.pop(context),);
    });
    
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: primeColor,
        title: Text('HomePage',style: TextStyle(color: Colors.white),),
        iconTheme: IconThemeData(color: Colors.white),
        actions: [
          IconButton(onPressed: (){
            signOut();
          }, icon: Icon(Icons.logout))
        ],
      ),
      body: _buildUserList(),
    );
  }

  Widget _buildUserList(){
    return StreamBuilder(stream: fireStore.collection('users').snapshots(),
        builder: (context,documentSnapshot){
          if(documentSnapshot.hasError){
            return Text('Something went to wrong!');
          }
          if(documentSnapshot.connectionState == ConnectionState.waiting){
            return Text('Loading...');
          }
          return Padding(
            padding: const EdgeInsets.only(top: 15.0),
            child: ListView(
              children: documentSnapshot.data!.docs.map<Widget>((doc) => _buildUserListItem(doc)).toList(),
            ),
          );
      
        });
  }

  Widget _buildUserListItem(DocumentSnapshot documentSnapshot){
    Map<String,dynamic> data = documentSnapshot.data()! as Map<String,dynamic>;

    if(_auth.currentUser!.email == data['email']){
       senderName = data['name'];
    }

    if(_auth.currentUser!.email != data['email']){
      return ListTile(
        leading: CircleAvatar(child: Icon(Icons.account_circle_outlined,color: primeColor,),),
        title: Text(data['name']),
        onTap: (){
          Navigator.push(context, MaterialPageRoute(builder: (context)=>
              ChatPage(receiverUserEmail: data['name'],receiverUserID: data['uid'], senderName: senderName,)));
        },
      );
    }else{
      return Container();
    }
  }
}
