package com.prashantdev.e_notebook

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
