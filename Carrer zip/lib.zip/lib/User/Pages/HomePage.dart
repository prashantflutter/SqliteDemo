import 'dart:async';

import 'package:careerguideline/AppConstant/AppTextStyle.dart';
import 'package:careerguideline/AppConstant/Appcolors.dart';
import 'package:careerguideline/Widgets/MyAppBar.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';

import '../../AppConstant/AppList.dart';
import 'CourseDetailsPage.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late PageController _pageController;

  int activePage = 1;
  @override
  void initState() {
    _pageController = PageController(viewportFraction: 0.8);
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: MyAppBar(title: 'User Home Page',automaticallyImplyLeading: false,),
      body: Column(
        children: [
          SizedBox(
            width: double.infinity,
            height: 200,
            child: PageView.builder(
                itemCount: images.length,
                pageSnapping: true,
                controller: _pageController,
                onPageChanged: (page) {
                  setState(() {
                    Timer(Duration(seconds: 1), () {
                      activePage = page;
                    });
                    activePage = page;
                  });
                },
                itemBuilder: (context,pagePosition){
                  return Container(
                    width: double.infinity,
                      margin: EdgeInsets.symmetric(horizontal: 6,vertical: 10),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        boxShadow: [
                          BoxShadow(
                            color: pLight2,
                            blurRadius: 1,
                            spreadRadius: 1,
                          )
                        ],
                        image: DecorationImage(image: AssetImage(images[pagePosition],),fit: BoxFit.cover,)
                      ),
                      // child: Image.asset(images[pagePosition],fit: BoxFit.cover,),
                  );
                }),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8.0),
              child: GridView.count(
                crossAxisCount: 2,
                children: List.generate(courseNameList.length, (index) {
                  return InkWell(
                    onTap: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context)=> CourseDetailsPage(titleOfCourse: courseNameList[index], id: index,)));
                    },
                    child: Padding(
                      padding:  EdgeInsets.all(8.0),
                      child: Container(
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: pW,
                          borderRadius: BorderRadius.circular(18),
                          boxShadow: [
                          BoxShadow(
                          color: Colors.black.withOpacity(0.2),
                          blurRadius: 5,
                          spreadRadius: 2,
                            offset: Offset(-2, 2)
                          ),
                          ],),
                        child: Text(courseNameList[index],style: titleStyle,textAlign: TextAlign.center,),
                      ),
                    ),
                  );
                }),
              ),
            ),
          ),

          
        ],
      ),
    );
  }
}
