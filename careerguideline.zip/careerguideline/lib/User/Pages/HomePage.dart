import 'dart:async';

import 'package:careerguideline/AppConstant/AppTextStyle.dart';
import 'package:careerguideline/AppConstant/Appcolors.dart';
import 'package:careerguideline/User/Pages/UserProfilePage.dart';
import 'package:careerguideline/Widgets/MyAppBar.dart';
import 'package:careerguideline/Widgets/MyNavigationBar.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';

import '../../AppConstant/AppList.dart';
import '../../Widgets/MyDrawer.dart';
import 'CourseDetailsPage.dart';
import 'HomePageView.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late PageController _pageController;

  int activePage = 1;
  int _selectedIndex = 0;
  static const List<Widget> _pages = <Widget>[
    HomePageView(),
    UserProfilePage()
  ];
  @override
  void initState() {
    _pageController = PageController(viewportFraction: 0.8);
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Center(
        child: _pages.elementAt(_selectedIndex), //New
      ),
      drawer: MyDrawer(context),
      bottomNavigationBar: MyNavigationBar(onTap:_onItemTapped,currentIndex: _selectedIndex),
    );
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }
}
