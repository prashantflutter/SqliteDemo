

import 'package:careerguideline/AppConstant/Appcolors.dart';
import 'package:flutter/cupertino.dart';

const textStyle = TextStyle(color: pDark,fontSize: 16);
const titleStyle = TextStyle(color: pDark,fontSize: 22,fontWeight: FontWeight.bold);
const title2Style = TextStyle(color: pDark,fontSize: 18,fontWeight: FontWeight.bold);