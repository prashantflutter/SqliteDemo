package com.example.career_guideline

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
