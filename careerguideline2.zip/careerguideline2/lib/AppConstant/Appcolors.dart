import 'dart:ui';

const pDark = Color(0xFF176B87);
const pLight1 = Color(0xFF86B6F6);
const pLight2 = Color(0xFFB4D4FF);
const pW = Color(0xFFEEF5FF);
const pWhite = Color(0xFFFFFFFF);