import 'package:careerguideline/AppConstant/AppTextStyle.dart';
import 'package:flutter/material.dart';
import '../AppConstant/Appcolors.dart';

Widget MyButton({required String title,double width = 130,required void Function()? onPressed}){
  return Container(
      width: width,
      height: 50,
      margin: EdgeInsets.only(top: 20),
      child: ElevatedButton(onPressed: onPressed, child: Text(title,style: TextStyle(fontSize: 16),)));
}

Widget MyTextButton({required String title,required void Function()? onPressed}){
  return InkWell(onTap: onPressed, child: Text(title,style: textStyle,));
}

Widget BackNow({required void Function()? onPressed}){
  return  Padding(
    padding: EdgeInsets.only(left: 8.0),
    child: IconButton(onPressed: onPressed, icon: Icon(Icons.arrow_back_ios,color: pWhite,)),
  );
}