import 'package:flutter/material.dart';


Widget MyNavigationBar({int currentIndex = 0,void Function(int)? onTap}){
  return BottomNavigationBar(

    currentIndex:currentIndex,
      onTap:onTap,
      items: [
        BottomNavigationBarItem(icon: Icon(Icons.home),label: 'Home',),
        BottomNavigationBarItem(icon: Icon(Icons.account_circle),label: 'Profile',)
      ]);
}