import 'package:dio/dio.dart';

class Api {
  const Api(this._dio);

  final Dio _dio;


  Future<Map<String, dynamic>> getPaymentTransactions({
    String accountId = 'anyOfflineAccount',
    int? pageNumber,
    int? pageSize = 100,
    String order = 'DESC',
  }) async {
    ArgumentError.checkNotNull(accountId, 'accountId');

    final queryParameters = <String, dynamic>{
      r'pageNumber': pageNumber,
      r'pageSize': pageSize,
      r'order': order,
    };
    queryParameters.removeWhere((k, v) => v == null);

    final result = await _dio.request<Map<String, dynamic>>(
      '/v1/paymentAccounts/$accountId/transactions',
      queryParameters: queryParameters,
      options: Options(
        method: 'GET',
        headers: <String, dynamic>{},
      ),
    );
    return result.data!;
  }

  Future<Map<String, dynamic>> getPayees({
    String accountId = 'anyOfflineAccount',
    int? pageNumber,
    int? pageSize,
  }) async {
    ArgumentError.checkNotNull(accountId, 'accountId');

    final queryParameters = <String, dynamic>{
      r'pageNumber': pageNumber,
      r'pageSize': pageSize
    };
    queryParameters.removeWhere((k, v) => v == null);

    final result = await _dio.request<Map<String, dynamic>>(
      '/v1/paymentAccounts/$accountId/payees',
      queryParameters: queryParameters,
      options: Options(
        method: 'GET',
        headers: <String, dynamic>{},
      ),
    );

    return result.data!;
  }

  Future<Map<String, dynamic>> pendingPayments({
    String accountId = 'anyOfflineAccount',
    int? pageNumber,
    int? pageSize,
  }) async {
    ArgumentError.checkNotNull(accountId, 'accountId');

    final queryParameters = <String, dynamic>{
      r'pageNumber': pageNumber,
      r'pageSize': pageSize
    };
    queryParameters.removeWhere((k, v) => v == null);

    final result = await _dio.request<Map<String, dynamic>>(
      '/v1/paymentAccounts/$accountId/pendingPayments',
      queryParameters: queryParameters,
      options: Options(
        method: 'GET',
        headers: <String, dynamic>{},
      ),
    );
    return result.data!;
  }
}
