import 'dart:developer';
import 'dart:io';

import 'package:aveosoft_test/utils/services/offlineModeBootstrap/mock_server_flutter_asset_loader.dart';
import 'package:mock_server/mock_server.dart';

final kFlutterTestMode = Platform.environment.containsKey('FLUTTER_TEST');

class OfflineModeBootstrapper {
  MockServer? offlineServer;

  Future<void> call() async {
    if (!kFlutterTestMode) {
      await _stopOfflineServer();

      await _startOfflineServer();
    }
  }

  Future<void> _stopOfflineServer() async {
    if (offlineServer == null) {
      return;
    }

    log('Stopping offline server');

    try {
      await offlineServer!.close(true);
    } catch (e) {
      log('Something went wrong while stopping the server...', error: e);
    }
    offlineServer = null;
  }

  Future<void> _startOfflineServer() async {
    log('Starting offline server');
    offlineServer = MockServer(assetLoader: MockServerFlutterAssetLoader());
    // Added exception handling for when running multiple simulators
    // only one instance of mock server needs to be running. So no need to crash
    try {
      await offlineServer!.start();
      log('Serving at https://${offlineServer!.server?.address.host}:${offlineServer!.server?.port}');
    } catch (err) {
      log('MockServer failed to start at https://${offlineServer!.server?.address.host}:${offlineServer?.server?.port}');
      log('$err');
    }
  }
}
