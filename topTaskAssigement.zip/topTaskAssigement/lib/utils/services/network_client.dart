import 'dart:developer';
import 'dart:io';

import 'package:dio/adapter.dart';
import 'package:dio/dio.dart';

class NetworkClient {
  NetworkClient({
    required String baseUrl,
  }) : dio = _initialize(
          baseUrl,
        );

  final Dio dio;

  static Dio _initialize(
    String baseUrl,
  ) {
    final Dio dio = Dio()
      ..options.baseUrl = baseUrl
      ..options.connectTimeout = 30000 // 30s
      ..options.receiveTimeout = 30000; // 30s

    dio.interceptors.add(LogInterceptor(
      requestBody: true,
      responseBody: true,
      logPrint: (object) => log(object.toString()),
    ));

    dio.transformer = ContentTypeTransformer();
    dio.setupNetworkConfig();
    return dio;
  }
}

extension DioConfigure on Dio {
  void setupNetworkConfig() {
    (httpClientAdapter as DefaultHttpClientAdapter).onHttpClientCreate =
        (HttpClient client) {
      client.badCertificateCallback =
          (X509Certificate cert, String host, int port) {
        return true;
      };
      return client;
    };
  }
}

/// Forces the content type from text/json to application/json
/// https://github.com/flutterchina/dio/issues/737
class ContentTypeTransformer extends DefaultTransformer {
  final contentType = 'content-type';
  @override
  Future transformResponse(RequestOptions options, ResponseBody response) {
    if (response.headers.containsKey(contentType) &&
        response.headers[contentType]?.first == 'text/json') {
      response.headers[contentType] = ['application/json'];
    }

    return super.transformResponse(options, response);
  }
}
