
import 'dart:math';

import 'package:aveosoft_test/api.dart';
import 'package:aveosoft_test/di/ab_injector.dart';
import 'package:aveosoft_test/modules/transactionsPage/Model/TransactionDataModel.dart';
import 'package:flutter/material.dart';

import 'Model/transactions_model2.dart';

class TransactionsPage extends StatefulWidget {
  const TransactionsPage({super.key});

  @override
  State<TransactionsPage> createState() => _TransactionsPageState();
}

class _TransactionsPageState extends State<TransactionsPage> {


  List<Transactions> transactions = [];
  Map<String, dynamic> data = {};
  int page = 1;
  List<TransactionDataModel> transactionList = [];
  ScrollController scrollController = ScrollController();
  ValueNotifier<int> listChange = ValueNotifier(0);
  @override
  void initState() {
    super.initState();

    init();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return SizedBox(
      width: double.infinity,
      height: double.infinity,
      child: RefreshIndicator(
        displacement: size.height*0.2,
        color: Colors.blueAccent,
        strokeWidth: 2,
        onRefresh: (){

          return Future<void>.delayed(const Duration(seconds: 2)).whenComplete(() async{

          });

        },
        child: ValueListenableBuilder(
          valueListenable: listChange,
          builder: (context, value, child) {
            return  transactionList.isNotEmpty ? ListView.builder(
                itemCount: transactionList.length,
                controller: scrollController,
                itemBuilder: (context,index){
                  debugPrint("data length == ${transactionList.length}");
                  final mIndex = transactionList[index];
                  var iconType  = mIndex.iconType;
                  return Container(
                    padding: EdgeInsets.symmetric(horizontal: size.width*0.05),
                    margin: EdgeInsets.symmetric(vertical: size.width*0.015,horizontal: size.width*0.025),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black12,
                            blurRadius: 2,
                            spreadRadius: 2,
                            offset: Offset(0, 2),
                          )
                        ]
                    ),
                    child: Column(
                      children: [
                        TitleWithData(title: 'Amount', data: mIndex.amount.toString()),
                        TitleWithData(title: 'index', data: index.toString()),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                TitleWithData(title: 'Debit Type', data: mIndex.debitCreditCode.toString()),
                                TitleWithData(title: 'Bal', data: mIndex.balance.toString()),
                              ],
                            ),
                            SizedBox(width: size.width*0.05,),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                TitleWithData(title: 'Type', data: iconType == 'null'?'N/A':iconType == 'CARD_BACKWARDS_ARROW'?'CARD BACKWARDS':mIndex.iconType??''),
                                TitleWithData(title: 'Avl Bal', data: mIndex.availableBalance.toString())
                              ],
                            ),
                          ],
                        ),
                      ],
                    ),
                  );
                }) : Container();
          }
        ),
      ),
    );

  }


  Widget TitleWithData({required String title,required String data}){
    return Padding(
      padding: EdgeInsets.only(bottom: 2),
      child: Row(
        children: [
          Text('$title :',style: CustomStyle.MyTextStyle(textColor: Colors.black,),),
          Padding(
            padding: EdgeInsets.only(left: 5),
            child: Text(data,overflow: TextOverflow.ellipsis,style: CustomStyle.MyTextStyle(textColor: Colors.grey,fontSize: 14,fontWeight: FontWeight.normal),),
          ),
        ],
      ),
    );
  }

  void init() async {
    data = await ABInjector.I<Api>().getPaymentTransactions();

    for(var i in data['transactions']){
      transactionList.add(TransactionDataModel.fromJson(i));
    }
    debugPrint('====Data === ${transactionList.length}');
    scrollController.addListener(() async {
      if (scrollController.position.maxScrollExtent == scrollController.position.pixels)  {
        page++;
        if(page == 2){
          Map<String, dynamic> newData = await ABInjector.I<Api>().getPaymentTransactions(pageNumber: page);
          for(var i in newData['transactions']){
            transactionList.add(TransactionDataModel.fromJson(i));
          }
          debugPrint('====Data Length === ${transactionList.length}');
          listChange.value = Random().nextInt(999999);
        }

      }
    });
    listChange.value = Random().nextInt(999999);
  }
}

class CustomStyle{
  static MyTextStyle({Color textColor = Colors.black,FontWeight fontWeight = FontWeight.w600,double fontSize = 18}){
   return TextStyle(color: textColor,fontWeight: fontWeight,fontSize: fontSize);
  }
}
