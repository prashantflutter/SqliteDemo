class TransactionsModel {
  List<Transactions>? transactions;
  Records? records;

  TransactionsModel({this.transactions, this.records});

  TransactionsModel.fromJson(Map<String, dynamic> json) {
    if (json['transactions'] != null) {
      transactions = <Transactions>[];
      json['transactions'].forEach((v) {
        transactions!.add(new Transactions.fromJson(v));
      });
    }
    records =
    json['records'] != null ? new Records.fromJson(json['records']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.transactions != null) {
      data['transactions'] = this.transactions!.map((v) => v.toJson()).toList();
    }
    if (this.records != null) {
      data['records'] = this.records!.toJson();
    }
    return data;
  }
}

class Transactions {
  double? amount;
  String? transactionId;
  String? transactionReference;
  String? transactionType;
  double? balance;
  double? availableBalance;
  String? debitCreditCode;
  String? transactionTypeClient;
  String? transactionTimestamp;
  String? iconType;
  Conversion? conversion;
  bool? scheduled;
  String? subTransactionType;
  String? creditorName;
  List<Fees>? fees;
  String? counterpartyName;

  Transactions(
      {this.amount,
        this.transactionId,
        this.transactionReference,
        this.transactionType,
        this.balance,
        this.availableBalance,
        this.debitCreditCode,
        this.transactionTypeClient,
        this.transactionTimestamp,
        this.iconType,
        this.conversion,
        this.scheduled,
        this.subTransactionType,
        this.creditorName,
        this.fees,
        this.counterpartyName});

  Transactions.fromJson(Map<String, dynamic> json) {
    amount = json['amount'];
    transactionId = json['transactionId'];
    transactionReference = json['transactionReference'];
    transactionType = json['transactionType'];
    balance = json['balance'];
    availableBalance = json['availableBalance'];
    debitCreditCode = json['debitCreditCode'];
    transactionTypeClient = json['transactionTypeClient'];
    transactionTimestamp = json['transactionTimestamp'];
    iconType = json['iconType'];
    conversion = json['conversion'] != null
        ? new Conversion.fromJson(json['conversion'])
        : null;
    scheduled = json['scheduled'];
    subTransactionType = json['subTransactionType'];
    creditorName = json['creditorName'];
    if (json['fees'] != null) {
      fees = <Fees>[];
      json['fees'].forEach((v) {
        fees!.add(new Fees.fromJson(v));
      });
    }
    counterpartyName = json['counterpartyName'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['amount'] = this.amount;
    data['transactionId'] = this.transactionId;
    data['transactionReference'] = this.transactionReference;
    data['transactionType'] = this.transactionType;
    data['balance'] = this.balance;
    data['availableBalance'] = this.availableBalance;
    data['debitCreditCode'] = this.debitCreditCode;
    data['transactionTypeClient'] = this.transactionTypeClient;
    data['transactionTimestamp'] = this.transactionTimestamp;
    data['iconType'] = this.iconType;
    if (this.conversion != null) {
      data['conversion'] = this.conversion!.toJson();
    }
    data['scheduled'] = this.scheduled;
    data['subTransactionType'] = this.subTransactionType;
    data['creditorName'] = this.creditorName;
    if (this.fees != null) {
      data['fees'] = this.fees!.map((v) => v.toJson()).toList();
    }
    data['counterpartyName'] = this.counterpartyName;
    return data;
  }
}

class Conversion {
  double? amount;
  String? currencyCode;
  String? rate;

  Conversion({this.amount, this.currencyCode, this.rate});

  Conversion.fromJson(Map<String, dynamic> json) {
    amount = json['amount'];
    currencyCode = json['currencyCode'];
    rate = json['rate'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['amount'] = this.amount;
    data['currencyCode'] = this.currencyCode;
    data['rate'] = this.rate;
    return data;
  }
}

class Fees {
  Charge? charge;
  String? transactionId;
  double? totalFeeCharged;
  String? currency;

  Fees({this.charge, this.transactionId, this.totalFeeCharged, this.currency});

  Fees.fromJson(Map<String, dynamic> json) {
    charge =
    json['charge'] != null ? new Charge.fromJson(json['charge']) : null;
    transactionId = json['transactionId'];
    totalFeeCharged = json['totalFeeCharged'];
    currency = json['currency'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.charge != null) {
      data['charge'] = this.charge!.toJson();
    }
    data['transactionId'] = this.transactionId;
    data['totalFeeCharged'] = this.totalFeeCharged;
    data['currency'] = this.currency;
    return data;
  }
}

class Charge {
  int? percentage;
  String? description;
  double? fixedAmount;
  String? currency;

  Charge({this.percentage, this.description, this.fixedAmount, this.currency});

  Charge.fromJson(Map<String, dynamic> json) {
    percentage = json['percentage'];
    description = json['description'];
    fixedAmount = json['fixedAmount'];
    currency = json['currency'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['percentage'] = this.percentage;
    data['description'] = this.description;
    data['fixedAmount'] = this.fixedAmount;
    data['currency'] = this.currency;
    return data;
  }
}

class Records {
  int? totalRecords;
  int? pageNumber;
  int? pageSize;

  Records({this.totalRecords, this.pageNumber, this.pageSize});

  Records.fromJson(Map<String, dynamic> json) {
    totalRecords = json['totalRecords'];
    pageNumber = json['pageNumber'];
    pageSize = json['pageSize'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['totalRecords'] = this.totalRecords;
    data['pageNumber'] = this.pageNumber;
    data['pageSize'] = this.pageSize;
    return data;
  }
}