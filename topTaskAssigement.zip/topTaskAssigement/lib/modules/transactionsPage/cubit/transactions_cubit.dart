import 'package:aveosoft_test/modules/transactionsPage/cubit/transactions_state.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class TransactionsCubit extends Cubit<TransactionsState> {
  TransactionsCubit({
    TransactionsState? initialState,
  }) : super(
          initialState ?? const TransactionsState(),
        );

  Future<void> loadInitialTransactions() async {
    emit(state.copyWith(isLoading: true));

    // simulate call api
    await Future.delayed(const Duration(seconds: 2));

    emit(state.copyWith(isLoading: false));
  }

  Future<void> loadNextPageOfTransactions() async {
    emit(state.copyWith(isLoading: true));

    // simulate call api
    await Future.delayed(const Duration(seconds: 2));

    emit(state.copyWith(isLoading: false));
  }
}
