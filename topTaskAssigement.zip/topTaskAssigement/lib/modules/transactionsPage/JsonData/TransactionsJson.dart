import 'dart:convert';

import 'package:flutter/services.dart';

class TransactionsJson {
  List _items = [];

// Fetch content from the json file
  Future<void> readJson() async {
    final String response = await rootBundle.loadString('packages/mock_server/assets/responses/user/payments/transactions/payment_transactions_1.json');
    final data = await json.decode(response);

      _items = data["transactions"];
      print("..number of items ${_items.length}");
  }
}
