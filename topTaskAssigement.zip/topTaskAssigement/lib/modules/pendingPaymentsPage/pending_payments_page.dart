// import 'package:aveosoft_test/api.dart';
// import 'package:aveosoft_test/di/ab_injector.dart';
import 'package:flutter/material.dart';

class PendingPaymentsPage extends StatefulWidget {
  const PendingPaymentsPage({super.key});

  @override
  State<PendingPaymentsPage> createState() => _PendingPaymentsPageState();
}

class _PendingPaymentsPageState extends State<PendingPaymentsPage> {
  @override
  void initState() {
    super.initState();

    // ABInjector.I<Api>().pendingPayments();
  }

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text('Pending Payments'),
    );
  }
}
