package com.example.aveosoft_test

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
