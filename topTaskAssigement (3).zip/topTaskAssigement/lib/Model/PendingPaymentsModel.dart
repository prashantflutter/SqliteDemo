class PendingPaymentsModel {
  int? amount;
  String? id;
  String? payeeId;
  String? reference;
  String? walletId;
  Schedule? schedule;

  PendingPaymentsModel(
      {this.amount,
        this.id,
        this.payeeId,
        this.reference,
        this.walletId,
        this.schedule});

  PendingPaymentsModel.fromJson(Map<String, dynamic> json) {
    amount = json['amount'];
    id = json['id'];
    payeeId = json['payeeId'];
    reference = json['reference'];
    walletId = json['walletId'];
    schedule = json['schedule'] != null
        ? new Schedule.fromJson(json['schedule'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['amount'] = this.amount;
    data['id'] = this.id;
    data['payeeId'] = this.payeeId;
    data['reference'] = this.reference;
    data['walletId'] = this.walletId;
    if (this.schedule != null) {
      data['schedule'] = this.schedule!.toJson();
    }
    return data;
  }
}

class Schedule {
  String? frequency;
  String? startDate;

  Schedule({this.frequency, this.startDate});

  Schedule.fromJson(Map<String, dynamic> json) {
    frequency = json['frequency'];
    startDate = json['startDate'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['frequency'] = this.frequency;
    data['startDate'] = this.startDate;
    return data;
  }
}
