class TransactionDataModel {
  double? amount;
  String? transactionId;
  String? transactionReference;
  String? transactionType;
  double? balance;
  double? availableBalance;
  String? debitCreditCode;
  String? transactionTypeClient;
  String? creditorName;
  String? iconType;
  bool? scheduled;
  String? transactionTimestamp;
  String? counterpartyName;
  List<Fees>? fees;
  Conversion? conversion;

  TransactionDataModel(
      {this.amount,
        this.transactionId,
        this.transactionReference,
        this.transactionType,
        this.balance,
        this.availableBalance,
        this.debitCreditCode,
        this.transactionTypeClient,
        this.creditorName,
        this.iconType,
        this.scheduled,
        this.transactionTimestamp,
        this.counterpartyName,
        this.fees,
        this.conversion});

  TransactionDataModel.fromJson(Map<String, dynamic> json) {
    amount = json['amount'];
    transactionId = json['transactionId'];
    transactionReference = json['transactionReference'];
    transactionType = json['transactionType'];
    balance = json['balance'];
    availableBalance = json['availableBalance'];
    debitCreditCode = json['debitCreditCode'];
    transactionTypeClient = json['transactionTypeClient'];
    counterpartyName = json['counterpartyName'];
    creditorName = json['creditorName'];
    iconType = json['iconType'];
    scheduled = json['scheduled'];
    transactionTimestamp = json['transactionTimestamp'];
    if (json['fees'] != null) {
      fees = <Fees>[];
      json['fees'].forEach((v) {
        fees!.add(new Fees.fromJson(v));
      });
    }
    conversion = json['conversion'] != null
        ? new Conversion.fromJson(json['conversion'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['amount'] = this.amount;
    data['transactionId'] = this.transactionId;
    data['transactionReference'] = this.transactionReference;
    data['transactionType'] = this.transactionType;
    data['balance'] = this.balance;
    data['availableBalance'] = this.availableBalance;
    data['debitCreditCode'] = this.debitCreditCode;
    data['transactionTypeClient'] = this.transactionTypeClient;
    data['counterpartyName'] = this.counterpartyName;
    data['creditorName'] = this.creditorName;
    data['iconType'] = this.iconType;
    data['scheduled'] = this.scheduled;
    data['transactionTimestamp'] = this.transactionTimestamp;
    if (this.fees != null) {
      data['fees'] = this.fees!.map((v) => v.toJson()).toList();
    }
    if (this.conversion != null) {
      data['conversion'] = this.conversion!.toJson();
    }
    return data;
  }
}

class Fees {
  Charge? charge;
  String? transactionId;
  double? totalFeeCharged;
  String? currency;

  Fees({this.charge, this.transactionId, this.totalFeeCharged, this.currency});

  Fees.fromJson(Map<String, dynamic> json) {
    charge =
    json['charge'] != null ? new Charge.fromJson(json['charge']) : null;
    transactionId = json['transactionId'];
    totalFeeCharged = json['totalFeeCharged'];
    currency = json['currency'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.charge != null) {
      data['charge'] = this.charge!.toJson();
    }
    data['transactionId'] = this.transactionId;
    data['totalFeeCharged'] = this.totalFeeCharged;
    data['currency'] = this.currency;
    return data;
  }
}

class Charge {
  int? percentage;
  String? description;
  double? fixedAmount;
  String? currency;

  Charge({this.percentage, this.description, this.fixedAmount, this.currency});

  Charge.fromJson(Map<String, dynamic> json) {
    percentage = json['percentage'];
    description = json['description'];
    fixedAmount = json['fixedAmount'];
    currency = json['currency'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['percentage'] = this.percentage;
    data['description'] = this.description;
    data['fixedAmount'] = this.fixedAmount;
    data['currency'] = this.currency;
    return data;
  }
}

class Conversion {
  double? amount;
  String? currencyCode;
  String? rate;

  Conversion({this.amount, this.currencyCode, this.rate});

  Conversion.fromJson(Map<String, dynamic> json) {
    amount = json['amount'];
    currencyCode = json['currencyCode'];
    rate = json['rate'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['amount'] = this.amount;
    data['currencyCode'] = this.currencyCode;
    data['rate'] = this.rate;
    return data;
  }
}
