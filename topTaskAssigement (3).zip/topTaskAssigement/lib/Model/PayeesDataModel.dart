class PayeesDataModel {
  String? id;
  String? name;
  String? accountNumber;
  String? sortCode;
  String? reference;

  PayeesDataModel(
      {this.id, this.name, this.accountNumber, this.sortCode, this.reference});

  PayeesDataModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    accountNumber = json['accountNumber'];
    sortCode = json['sortCode'];
    reference = json['reference'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['accountNumber'] = this.accountNumber;
    data['sortCode'] = this.sortCode;
    data['reference'] = this.reference;
    return data;
  }
}