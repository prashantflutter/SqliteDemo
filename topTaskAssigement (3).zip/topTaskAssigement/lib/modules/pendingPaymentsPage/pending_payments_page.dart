import 'dart:math';

import 'package:flutter/material.dart';
import '../../Model/PendingPaymentsModel.dart';
import '../../api.dart';
import '../../di/ab_injector.dart';
import '../transactionsPage/transactions_page.dart';

class PendingPaymentsPage extends StatefulWidget {
  const PendingPaymentsPage({super.key});

  @override
  State<PendingPaymentsPage> createState() => _PendingPaymentsPageState();
}

class _PendingPaymentsPageState extends State<PendingPaymentsPage> {

  Map<String, dynamic> PendingPaymentsData = {};
  List<PendingPaymentsModel> PendingPaymentsList = [];
  ScrollController scrollController = ScrollController();
  ValueNotifier<int> PendingPaymentsChange = ValueNotifier(0);
  bool isLoading = false;
  int page = 1;
  @override
  void initState() {
    super.initState();
    init();
    // ABInjector.I<Api>().pendingPayments();
  }

  @override
  Widget build(BuildContext context) {
    // return const Center(
    //   child: Text('Pending Payments'),
    // );
    final size = MediaQuery.of(context).size;
    return SizedBox(
      width: double.infinity,
      height: double.infinity,
      child: RefreshIndicator(
        displacement: size.height*0.2,
        color: Colors.deepPurple,
        strokeWidth: 2,
        onRefresh: (){
          return Future<void>.delayed(const Duration(seconds: 2)).whenComplete(() async{
            init();
          });
        },
        child: ValueListenableBuilder(
            valueListenable: PendingPaymentsChange,
            builder: (context, value, child) {
              return  Scaffold(
                appBar: AppBar(
                  backgroundColor: Colors.deepPurple,
                  title: Text('Pending Payments',style: CustomStyle.MyTextStyle(textColor: Colors.white,fontSize: 20),),
                  centerTitle: true,
                ),
                body: PendingPaymentsList.isNotEmpty ?ListView.builder(
                    itemCount: PendingPaymentsList.length,
                    controller: scrollController,
                    itemBuilder: (context,index){
                      debugPrint("PendingPayments length == ${PendingPaymentsList.length}");
                      final mIndex = PendingPaymentsList[index];
                      return Card(
                        color: Colors.white,
                        elevation: 1,
                        shadowColor: Colors.deepPurple,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero
                        ),
                        margin: EdgeInsets.symmetric(vertical: size.width*0.020,horizontal: size.width*0.030),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 15,vertical: 5),
                          child:  Row(
                            children: [
                              Icon(Icons.account_circle,color: Colors.deepPurple,size: size.height*0.045,),
                              SizedBox(width: size.height*0.015,),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  TitleWithData(title: 'Name', data: mIndex.amount.toString()),
                                  TitleWithData(title: 'Account Number', data: mIndex.amount.toString()),
                                  TitleWithData(title: 'Reference', data: mIndex.schedule!.startDate.toString()),
                                ],
                              ),
                            ],
                          ),
                        ),
                      );
                    }) : Center(child: CircularProgressIndicator(color: Colors.deepPurple,)),
              );
            }
        ),
      ),
    );
  }

  Widget TitleWithData({required String title,required String data}){
    return Padding(
      padding: EdgeInsets.only(bottom: 2),
      child: Row(
        children: [
          Text('$title :',style: CustomStyle.MyTextStyle(textColor: Colors.black54,fontSize: 14),),
          Padding(
            padding: EdgeInsets.only(left: 5),
            child: Text(data,overflow: TextOverflow.ellipsis,style: CustomStyle.MyTextStyle(textColor: Colors.black,fontSize: 14,fontWeight: FontWeight.bold),),
          ),
        ],
      ),
    );
  }
  void init() async {
    PendingPaymentsData = await ABInjector.I<Api>().getPayees();

    PendingPaymentsList.clear();
    for(var i in PendingPaymentsData['payments']){
      PendingPaymentsList.add(PendingPaymentsModel.fromJson(i));
    }
    debugPrint('==== PendingPayments Data === ${PendingPaymentsList.length}');
    scrollController.addListener(() async {

      if (scrollController.position.maxScrollExtent == scrollController.position.pixels)  {
        page++;
        isLoading = true;
        if(page == 2){
          Map<String, dynamic> paymentsData = await ABInjector.I<Api>().pendingPayments(pageNumber: page).whenComplete(() => isLoading = false);
          for(var i in paymentsData['payments']){
            PendingPaymentsList.add(PendingPaymentsModel.fromJson(i));
          }
          debugPrint('==== PendingPayments Data Length === ${PendingPaymentsList.length}');
          PendingPaymentsChange.value = Random().nextInt(999999);
        }
      }
    });
    PendingPaymentsChange.value = Random().nextInt(999999);
  }
  
}
