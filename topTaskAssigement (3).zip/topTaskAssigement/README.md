# aveosoft_test

Project skeleton for Aveosoft Flutter Developer candidates to build on.

## Getting Started

This project is built with the version of flutter 3.13.8.

This project runs on both iOS and Android. When you run the app, you will see a home page with a bottom tab bar. There will be 3 tabs, Transactions, Payees and Pending Payments.

## Note on current project structure

The app runs a local offline mock server (packages/mock_server), which serves up json responses on a couple of endpoints.

- transactions
- payees
- pendingPayments

These endpoints and the code required to call them are written in the `api.dart` class. They currently return just a raw json `Map`.
Feel free to parse the json to models as you see fit.

This current project uses some commonly used packages:

- flutter_bloc: for state management and isolating business logic
- get_it: for dependency injection
- dio: for network calls


## The task

**Goal:**

The aim of this set project is to gather your approach to solving common feature problems within the flutter framework and dart language.
Your solution should be able to build and run successfully. Any tests you may write should also run and pass successfully.

Below outlines a list of features across multiple tabs. Feel free to spend as much or as little time on implementing the features.
We do not expect you to implement all, or even more than one tab.

Please try and write tests for any functionality you implement. These should cover anything from business logic contained in a bloc,
command or service. Along with how you might test the visual widget side of the implementation.

When creating your solution. Please consider the following non-functional requirements also

- project structure
- good architectural practises following SOLID principles
- code quality, maintenance and testability
- potential points of reuse
- documentation through clear code or any supplementary 
- solution considerate of a scaling team with potential area ownership

There is a document at the root of the project called `FURTHER_CONSIDERATIONS.md`. You should aim to use it as a written summary of things that might not have made it into your solution (due to time constraints). Describing how you might scale a project like this, any reasoning behind any decisions you might have made during implementation. 

It is important that as engineers, we are aware that a short or mid-term solution might be appropriate for a feature, but to know what the trade-offs and technical debt we may need to pay down in the future.

## Features

**Transactions tab:**

Please further implement the transactions tab. Below are a list of features business have asked for.
Feel free to change order of priority as you see fit and implement as much as you'd like. 
You can always describe in the `FURTHER_CONSIDERATIONS.md` doc how you might have implemented certain features.

- load the initial page of transactions and present some data to the user (the API currently loads default first page).
  - amount
  - whether it is a debit (money out DBIT `debitCreditCode`)
  - whether it is a credit (money in CRDT `debicCreditCode`)
  - show the `counterpartyName` if its present, otherwise show the `transactionReference` which is there for all transactions
- show loading state
- handle if there's an error loading initial page, allowing user to retry (understand that mock endpoint won't throw error directly)

---
- if the `totalRecords` of the initial transactions page is greater that the page size, we can assume there's another page to load.
  - implement fetching a secondary page. You can choose the UI/UX on how to implement this. e.g, lazy load, explicit button at bottom of list.
  - API call defaults to pageNumber of 1. The next page will be page number 2. It can be passed as a query parameter to the api call.
  - show user you are loading a new page

---
- implement a pull to refresh transactions
  - clearing all data to show initial page again if successful
  - dont clear existing transactions if there is an error when manually refreshing


**Payees tab:**

This tab follows the same requirements as when you loaded initial transactions. Except loading payees instead. 
- Loading initial page and handling errors and loading appropriately
- representing data from API response
- loading subsequent pages
- pulling to refresh


**Pending payments tab:**

This tab follows the same requirements as when you loaded initial transactions. Except loading pending payments instead. 
- Loading initial page and handling errors and loading appropriately
- representing data from API response
- loading subsequent pages
- pulling to refresh


# Notes
Flutter is a UIKit framework that has many widgets to help build complex and beautiful UI's. Google's goal is to make building these UI's simple for developers. Although it is important to show a grasp for some of the common widgets within the Flutter framework in your solution, we know engineers don't always make the best designers. So function over form is perfectly fine.

The framework can be learnt. This task is somewhat more focused on engineering a solution within Dart and Flutter. How you approach a problem, assert that your solution works and consider reuse and scale across multiple team members and screens.

## Submission

Please feel free to use this projects git and commit as much or as little as you want. When you are happy to submit, please zip up the file and reply back to the email who shared this task with you.

## Thank You

We believe that code and a complementing summary is a good way to assess an applicants approach to common features/problems. Where they are empowered to own the entire code base and/or architecture in a project that will hopefully be maintained and added to for a long time.

Thank you for taking the time to work on the above issues. We understand and appreciate that work-life balance is important and ask that you only take on as much as you are happy to do so.