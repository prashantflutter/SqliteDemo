import 'dart:io';

import 'package:mock_server/src/asset_loader/mock_server_asset_loader.dart';
import 'package:shelf/shelf.dart' as shelf;

// ignore: avoid_classes_with_only_static_members
class ResponseHelpers {
  static Future<shelf.Response> localHtml({
    required String assetPath,
    required shelf.Request request,
  }) async {
    final body = await globalAssetLoader!.dataForAsset(assetPath);
    return shelf.Response.ok(
      body,
      headers: {
        HttpHeaders.contentTypeHeader: ContentType.html.mimeType,
        'Access-Control-Allow-Origin': request.headers['origin'] ?? ''
      },
    );
  }

  static Future<shelf.Response> ok(shelf.Request request) async {
    return shelf.Response(
      200,
      headers: {
        'Access-Control-Allow-Origin': request.headers['origin'] ?? '',
      },
    );
  }

  static Future<shelf.Response> created(shelf.Request request) async {
    return shelf.Response(
      201,
      headers: {
        'Access-Control-Allow-Origin': request.headers['origin'] ?? '',
      },
    );
  }

  static Future<shelf.Response> noContent(shelf.Request request) async {
    return shelf.Response(
      204,
      headers: {
        'Access-Control-Allow-Origin': request.headers['origin'] ?? '',
      },
    );
  }

  static Future<shelf.Response> error({
    int code = 500,
    required shelf.Request request,
  }) async {
    return shelf.Response(
      code,
      headers: {
        'Access-Control-Allow-Origin': request.headers['origin'] ?? '',
      },
    );
  }

  static Future<shelf.Response> badRequest({
    String? body,
    required shelf.Request request,
    int statusCode = 400,
  }) async {
    return shelf.Response(
      statusCode,
      body: body,
      headers: {
        HttpHeaders.contentTypeHeader: ContentType.json.mimeType,
        'Access-Control-Allow-Origin': request.headers['origin'] ?? ''
      },
    );
  }

  static shelf.Response jsonResponse({
    String? body,
    required shelf.Request request,
    int statusCode = 200,
  }) {
    return shelf.Response(
      statusCode,
      body: body,
      headers: {
        HttpHeaders.contentTypeHeader: ContentType.json.mimeType,
        'Access-Control-Allow-Origin': request.headers['origin'] ?? ''
      },
    );
  }

  static Future<shelf.Response> unauthorized(shelf.Request request) async {
    return shelf.Response(401, headers: {
      'Access-Control-Allow-Origin': request.headers['origin'] ?? '',
    });
  }

  static Future<shelf.Response> notFound(shelf.Request request) async {
    return shelf.Response(404, headers: {
      'Access-Control-Allow-Origin': request.headers['origin'] ?? '',
    });
  }
}
