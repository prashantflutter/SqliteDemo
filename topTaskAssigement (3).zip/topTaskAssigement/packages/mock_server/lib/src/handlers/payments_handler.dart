import 'dart:convert';
import 'dart:math';

import 'package:mock_server/mock_server.dart';
import 'package:mock_server/src/handlers/mock_request_handler.dart';
import 'package:mock_server/src/helpers/response_helpers.dart';
import 'package:shelf/shelf.dart' as shelf;

class PaymentsHandler extends MockRequestHandler {
  @override
  bool canHandle(shelf.Request request) {
    final path = request.requestedUri.path;
    return _matchMakePayment(path, request.method) ||
        _matchTransactionsPath(path) ||
        _matchPayees(path, request.method) ||
        _matchPendingPayments(path, request.method) ||
        _matchDeletePayee(path, request.method) ||
        _matchPendingTransactionsPath(path) ||
        _matchDirectDebits(path, request.method) ||
        _matchCustomerDetails(path) ||
        _matchCashbackTransactionsPath(path);
  }

  @override
  Future<shelf.Response> handle(shelf.Request request) async {
    final path = request.requestedUri.path;
    final method = request.method;
    if (_matchMakePayment(path, method)) {
      final content = await request.readAsString();
      final reqBody = jsonDecode(content) as Map<String, dynamic>?;

      final body = json.encode(_makePaymentJson(reqBody));

      return ResponseHelpers.jsonResponse(body: body, request: request);
    } else if (_matchTransactionsPath(path)) {
      return await _handleTransation(request, path);
    } else if (_matchPendingTransactionsPath(path)) {
      return await _handlePendingTransation(request, path);
    } else if (_matchPayees(path, request.method)) {
      return await _handlePayees(request, path);
    } else if (_matchDeletePayee(path, request.method)) {
      return ResponseHelpers.ok(request);
    } else if (_matchPendingPayments(path, request.method)) {
      return await _handlePendingPayments(request, path);
    } else if (_matchDirectDebits(path, request.method)) {
      return await _handleDirectDebits(request, path);
    }

    return shelf.Response.internalServerError();
  }

  Future<shelf.Response> _handleTransation(
      shelf.Request request, String path) async {
    final qParams = request.requestedUri.queryParameters;

    int pageNumber = 1;

    if (qParams.containsKey('pageNumber')) {
      pageNumber = int.parse(qParams['pageNumber']!);
    }

    try {
      final body = await globalAssetLoader!.loadUserResponse(
          'payments/transactions/payment_transactions_$pageNumber.json');
      return ResponseHelpers.jsonResponse(
        body: body.toString(),
        request: request,
      );
    } catch (e) {
      return shelf.Response.notFound('');
    }
  }

  Future<shelf.Response> _handlePendingTransation(
      shelf.Request request, String path) async {
    final qParams = request.requestedUri.queryParameters;

    int pageNumber = 1;

    if (qParams.containsKey('pageNumber')) {
      pageNumber = int.parse(qParams['pageNumber']!);
    }

    try {
      final body = await globalAssetLoader!.loadUserResponse(
          'payments/transactions/payment_pendingTransactions_$pageNumber.json');
      return ResponseHelpers.jsonResponse(
        body: body.toString(),
        request: request,
      );
    } catch (e) {
      return shelf.Response.notFound('');
    }
  }

  Future<shelf.Response> _handlePayees(
      shelf.Request request, String path) async {
    final qParams = request.requestedUri.queryParameters;

    int pageNumber = 1;

    if (qParams.containsKey('pageNumber')) {
      pageNumber = int.parse(qParams['pageNumber']!);
    }

    try {
      final body = await globalAssetLoader!
          .loadUserResponse('payments/payees/payees_$pageNumber.json');
      return ResponseHelpers.jsonResponse(
        body: body.toString(),
        request: request,
      );
    } catch (e) {
      return shelf.Response.notFound('');
    }
  }

  /// See if it matches path '/v3/payments' with a POST http method
  bool _matchMakePayment(String path, String httpMethod) {
    return path == '/v3/payments' && httpMethod.toLowerCase() == 'post';
  }

  Map<String, dynamic> _makePaymentJson(
    Map<String, dynamic>? reqBody, {
    String state = 'COMPLETED',
  }) {
    Map<String, dynamic> body = {};
    if (reqBody != null) {
      body = reqBody;
    }
    Map<String, dynamic>? reqPayee = {};
    if (body['payee'] != null) {
      reqPayee = body['payee'] as Map<String, dynamic>?;
    }

    return {
      'accountId': body['accountId'] ?? 'accountId',
      'amount': body['amount'] ?? 123.45,
      'payee': {
        'accountNumber': reqPayee!['accountNumber'] ?? '12345678',
        'name': reqPayee['name'] ?? 'Mr Pay Yee',
        'reference': reqPayee['reference'] ?? 'reference',
        'sortCode': reqPayee['sortCode'] ?? '123456'
      },
      'payeeId': body['payeeId'] ?? 'payeeId',
      'reference': body['reference'] ?? 'reference',
      'schedule': {
        'endDate': '2021-04-08',
        'frequency': 'ANNUAL',
        'startDate': '2021-04-08'
      },
      'state': state,
      'walletId': body['walletId'] ?? 'walletId'
    };
  }

  Future<shelf.Response> _handleDirectDebits(
      shelf.Request request, String path) async {
    final qParams = request.requestedUri.queryParameters;

    int pageNumber = 1;
    int pageSize = 500;

    if (qParams.containsKey('pageNumber')) {
      pageNumber = int.parse(qParams['pageNumber']!);
    }

    if (qParams.containsKey('pageSize')) {
      pageSize = int.parse(qParams['pageSize']!);
    }

    try {
      final body = await globalAssetLoader!.loadUserResponse(
          'payments/directDebits/directDebits_$pageNumber.json');

      final json = jsonDecode(body);
      final payments = json['directDebitMandates'] as List<dynamic>;

      final end = min(pageSize, payments.length);

      json['directDebitMandates'] = payments.getRange(0, end).toList();

      return ResponseHelpers.jsonResponse(
        body: jsonEncode(json),
        request: request,
      );
    } catch (e) {
      return shelf.Response.notFound('');
    }
  }

  Future<shelf.Response> _handlePendingPayments(
      shelf.Request request, String path) async {
    final qParams = request.requestedUri.queryParameters;

    int pageNumber = 1;
    int pageSize = 500;

    if (qParams.containsKey('pageNumber')) {
      pageNumber = int.parse(qParams['pageNumber']!);
    }

    if (qParams.containsKey('pageSize')) {
      pageSize = int.parse(qParams['pageSize']!);
    }

    try {
      final body = await globalAssetLoader!.loadUserResponse(
          'payments/pendingPayments/pendingPayments_$pageNumber.json');

      final json = jsonDecode(body);
      final payments = json['payments'] as List<dynamic>;

      final end = min(pageSize, payments.length);

      json['payments'] = payments.getRange(0, end).toList();

      return ResponseHelpers.jsonResponse(
        body: jsonEncode(json),
        request: request,
      );
    } catch (e) {
      return shelf.Response.notFound('');
    }
  }

  /// See if it matches path 'v1/paymentAccounts/{accountId}/transactions'
  bool _matchTransactionsPath(String path) {
    final regex = RegExp(r'\/v1\/paymentAccounts\/\S+\/transactions');
    final hasMatch = regex.hasMatch(path);
    return hasMatch;
  }

  /// See if it matches path 'v1/paymentAccounts/{accountId}/pendingTransactions'
  bool _matchPendingTransactionsPath(String path) {
    final regex = RegExp(r'\/v1\/paymentAccounts\/\S+\/pendingTransactions');
    final hasMatch = regex.hasMatch(path);
    return hasMatch;
  }

  /// See if it matches path 'v1/paymentAccounts/{accountId}/cashbackTransactions'
  bool _matchCashbackTransactionsPath(String path) {
    final regex = RegExp(r'\/v1\/paymentAccounts\/\S+\/cashbackTransactions');
    final hasMatch = regex.hasMatch(path);
    return hasMatch;
  }

  /// See if it matches path 'v1/paymentAccounts/{accountId}/payees'
  bool _matchPayees(String path, String httpMethod) {
    final regex = RegExp(r'\/v1\/paymentAccounts\/\S+\/payees');
    final hasMatch = regex.hasMatch(path);
    return hasMatch && httpMethod.toLowerCase() == 'get';
  }

  /// See if it matches path 'v3/payees/{payeeId}'
  bool _matchDeletePayee(String path, String httpMethod) {
    final regex = RegExp(r'\/v3\/payees\/\S+');
    final hasMatch = regex.hasMatch(path);
    return hasMatch && httpMethod.toLowerCase() == 'delete';
  }

  /// See if it matches path 'v1/fms/businessCustomers/{customerId}'
  bool _matchCustomerDetails(String path) {
    final regex = RegExp(r'\/v1\/fms\/businessCustomers\/\S+');
    final hasMatch = regex.hasMatch(path);
    return hasMatch;
  }

  /// See if it matches path 'v1/paymentAccounts/{accountId}/pendingPayments'
  bool _matchPendingPayments(String path, String httpMethod) {
    final regex = RegExp(r'\/v1\/paymentAccounts\/\S+\/pendingPayments');
    final hasMatch = regex.hasMatch(path);
    return hasMatch && httpMethod.toLowerCase() == 'get';
  }

  /// See if it matches path 'v1/paymentAccounts/{accountId}/mandates'
  bool _matchDirectDebits(String path, String httpMethod) {
    final regex = RegExp(r'\/v1\/paymentAccounts\/\S+\/mandates');
    final hasMatch = regex.hasMatch(path);
    return hasMatch && httpMethod.toLowerCase() == 'get';
  }
}
