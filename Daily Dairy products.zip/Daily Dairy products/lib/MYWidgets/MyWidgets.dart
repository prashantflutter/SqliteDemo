import 'package:dailydairyproducts/Constant/AppStyle.dart';
import 'package:flutter/material.dart';

import '../Constant/AppColors.dart';

Widget MyTextForm({required BuildContext context,required TextEditingController controller,required String hintText,double horizontal = 20,
  Widget? suffixIcon,Widget? prefixIcon,bool obscureText = false}){
  final size  = MediaQuery.of(context).size;
   double padHorizontal = size.width*0.08;
  return  Padding(
    padding: EdgeInsets.symmetric(horizontal: padHorizontal),
    child: TextFormField(
      controller: controller,
      cursorColor: pBlue,
      obscureText: obscureText,
      decoration: InputDecoration(
        hintText: 'Enter Email',
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(color: pBlue),
          borderRadius: BorderRadius.circular(50),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(color: pBlue),
          borderRadius: BorderRadius.circular(50),
        ),
        contentPadding: EdgeInsets.symmetric(horizontal: horizontal),
        suffixIcon: suffixIcon,
        prefixIcon: prefixIcon,
      ),

    ),
  );
}

Widget MyRowTextForm({required BuildContext context,required TextEditingController controller,required String hintText,double horizontal = 20,
  Widget? suffixIcon,Widget? prefixIcon,TextInputType? keyboardType,int? maxLength,bool obscureText = false}){
  final size  = MediaQuery.of(context).size;
  return  Padding(
    padding: const EdgeInsets.only(top: 13),
    child: TextFormField(
      controller: controller,
      cursorColor: pBlue,
      keyboardType: keyboardType,
      obscureText: obscureText,
      maxLength: maxLength,
      decoration: InputDecoration(
        hintText: hintText,
        hintStyle: MyTextStyle(color: pGrey,fontWeight: FontWeight.w400),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(color: pBlue),
          borderRadius: BorderRadius.circular(50),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(color: pBlue),
          borderRadius: BorderRadius.circular(50),
        ),
        contentPadding: EdgeInsets.symmetric(horizontal: horizontal),
        counterText: '',
        suffixIcon: suffixIcon,
        prefixIcon: prefixIcon,
      ),

    ),
  );
}


Widget MyButton({required BuildContext context,required String title,required void Function()? onPressed,}){
  final size  = MediaQuery.of(context).size;
  return Container(
    width: size.width*0.35,
    margin: EdgeInsets.only(top: 15),
    child: ElevatedButton(
        style: ElevatedButton.styleFrom(
            backgroundColor: pBlue,
            elevation: 2
        ),
        onPressed: onPressed,
        child: Text(title,style: MyTextStyle(),)),
  );
}
Widget MyTextButton({required String title,required void Function()? onTap}){
  return InkWell(
      onTap:onTap,
      child:Text(title,style: MyTextStyle(color: pBlue),));
}

ScaffoldFeatureController<SnackBar, SnackBarClosedReason> MyDialog({required BuildContext context,required String title,Color backgroundColor = pRed,IconData? icon = Icons.error_outline,Color? iconColor = Colors.redAccent}){
  return ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content:
      Row(
        children: [
          Icon(icon,color: pWhite,),
          SizedBox(width: 10,),
          Text(title,style: MyTextStyle(),),
        ],
      ),backgroundColor: backgroundColor,)
  );
}

Widget MyListView({void Function()? onTap,required String imageURL,required String productName,required String productPrice}){
  return GestureDetector(
    onTap: (){},
    child: Padding(
      padding: const EdgeInsets.all(10.0),
      child: Card(
        elevation: 2,
        surfaceTintColor: pWhite,
        color: pWhite,
        child: Column(children: [
          Image.asset(imageURL,width: 100,height: 100,),
          SizedBox(height: 20,),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            child: Divider(height: 1,color: pBlue,),
          ),
          Text(productName,),
          Text(productPrice),
        ],),
      ),
    ),
  );
}
