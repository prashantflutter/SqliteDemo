
import 'package:flutter/material.dart';

const pBlue = Color(0xFF1666e1);
const pGrey = Color(0xff898b8e);
const pWhite = Color(0xFFFFFFFF);
const pBlack = Color(0xFF000000);
const pGreen= Color(0xFF66BB6A);
const pRed= Color(0xFFF64636);