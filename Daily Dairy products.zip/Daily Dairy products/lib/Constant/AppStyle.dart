

import 'package:dailydairyproducts/Constant/AppColors.dart';
import 'package:flutter/material.dart';

 TextStyle MyTextStyle({Color color = pWhite,double fontSize = 14,FontWeight fontWeight = FontWeight.w400}){
   return TextStyle(color: color,fontSize: fontSize,fontWeight:fontWeight);
 }