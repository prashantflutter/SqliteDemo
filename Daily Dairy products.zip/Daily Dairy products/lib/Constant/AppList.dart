

import 'package:dailydairyproducts/AppModel/MilkProductModel.dart';

 List<MilkProductModel> milkProductList = [
  MilkProductModel('assets/Milk/gold.png', 'Amul Gold', '\u{20B9}32/-'),
  MilkProductModel('assets/Milk/govardahan.png', 'Govardahan Gold', '\u{20B9}31/-'),
  MilkProductModel('assets/Milk/mahi.png', 'Mahi Gold', '\u{20B9}28/-'),
  MilkProductModel('assets/Milk/taaza.png', 'Amul Taaza', '\u{20B9}18/-'),
];


List<MilkProductModel> cheeseProductList = [
 MilkProductModel('assets/Cheese/amul.jpg', 'Amul Cheese', '\u{20B9}100/-'),
 MilkProductModel('assets/Cheese/britannia-1.png', 'Britannia Cheese', '\u{20B9}80/-'),
 MilkProductModel('assets/Cheese/govardhan.png', 'Govardahan Cheese', '\u{20B9}110/-'),
 MilkProductModel('assets/Cheese/go.png', 'Govardahan Cheese', '\u{20B9}90/-'),
 MilkProductModel('assets/Cheese/britannia-2.png', 'Britannia Slices', '\u{20B9}45/-'),
 MilkProductModel('assets/Cheese/amul.jpg', 'Amul Slices', '\u{20B9}75/-'),
];

List<MilkProductModel> paneerProductList = [
 MilkProductModel('assets/Paneer/amul.jpg', 'Amul Paneer', '\u{20B9}252/-'),
 MilkProductModel('assets/Paneer/ananda.jpg', 'Govardahan Paneer', '\u{20B9}160/-'),
 MilkProductModel('assets/Paneer/govardhan.png', 'Mahi Paneer', '\u{20B9}149/-'),
 MilkProductModel('assets/Paneer/motherdairy.jpg', 'Motherdairy Paneer', '\u{20B9}99/-'),
];

List<MilkProductModel> butterProductList = [
 MilkProductModel('assets/Butter/amul.jpg', 'Amul Butter', '\u{20B9}252/-'),
 MilkProductModel('assets/Butter/britannia.png', 'Britannia Paneer', '\u{20B9}160/-'),
 MilkProductModel('assets/Butter/govardhan.png', 'Govardhan Paneer', '\u{20B9}149/-'),
 MilkProductModel('assets/Butter/kwality.png', 'Kwality Paneer', '\u{20B9}99/-'),
];
