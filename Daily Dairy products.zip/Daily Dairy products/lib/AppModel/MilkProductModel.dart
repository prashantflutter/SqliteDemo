
class MilkProductModel{
  String? image;
  String? name;
  String? price;

  MilkProductModel(this.image, this.name, this.price);

}