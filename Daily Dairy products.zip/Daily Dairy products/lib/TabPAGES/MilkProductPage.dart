import 'package:dailydairyproducts/Constant/AppList.dart';
import 'package:dailydairyproducts/MYWidgets/MyWidgets.dart';
import 'package:flutter/material.dart';

import '../Constant/AppColors.dart';

class MilkProductPage extends StatefulWidget {
  const MilkProductPage({super.key});

  @override
  State<MilkProductPage> createState() => _MilkProductPageState();
}

class _MilkProductPageState extends State<MilkProductPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GridView.count(
        crossAxisCount: 2,
        children: List.generate(
            milkProductList.length, (index){
          return MyListView(
              imageURL: milkProductList[index].image.toString(),
              productName: milkProductList[index].name.toString(),
              productPrice: milkProductList[index].price.toString());
        }),

      )
    );
  }
}
