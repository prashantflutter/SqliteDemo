import 'package:dailydairyproducts/Constant/AppColors.dart';
import 'package:dailydairyproducts/Constant/AppList.dart';
import 'package:flutter/material.dart';

import '../MYWidgets/MyWidgets.dart';

class ButterProductPage extends StatefulWidget {
  const ButterProductPage({super.key});

  @override
  State<ButterProductPage> createState() => _ButterProductPageState();
}

class _ButterProductPageState extends State<ButterProductPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GridView.count(
        crossAxisCount: 2,
        children: List.generate(
            butterProductList.length, (index){
          return MyListView(
              imageURL: butterProductList[index].image.toString(),
              productName: butterProductList[index].name.toString(),
              productPrice: butterProductList[index].price.toString());
        }),

      )
    );
  }

}
