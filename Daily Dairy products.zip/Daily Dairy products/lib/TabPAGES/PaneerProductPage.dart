import 'package:dailydairyproducts/Constant/AppList.dart';
import 'package:flutter/material.dart';

import '../Constant/AppColors.dart';
import '../MYWidgets/MyWidgets.dart';

class PaneerProductPage extends StatefulWidget {
  const PaneerProductPage({super.key});

  @override
  State<PaneerProductPage> createState() => _PaneerProductPageState();
}

class _PaneerProductPageState extends State<PaneerProductPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GridView.count(
        crossAxisCount: 2,
        children: List.generate(
            paneerProductList.length, (index){
          return MyListView(
              imageURL: paneerProductList[index].image.toString(),
              productName: paneerProductList[index].name.toString(),
              productPrice: paneerProductList[index].price.toString());
        }),

      )
    );
  }
}
