import 'package:dailydairyproducts/Constant/AppList.dart';
import 'package:flutter/material.dart';

import '../Constant/AppColors.dart';
import '../MYWidgets/MyWidgets.dart';

class CheeseProductPage extends StatefulWidget {
  const CheeseProductPage({super.key});

  @override
  State<CheeseProductPage> createState() => _CheeseProductPageState();
}

class _CheeseProductPageState extends State<CheeseProductPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GridView.count(
        crossAxisCount: 2,
        children: List.generate(
            cheeseProductList.length, (index){
          return MyListView(
              imageURL: cheeseProductList[index].image.toString(),
              productName: cheeseProductList[index].name.toString(),
              productPrice: cheeseProductList[index].price.toString());
        }),

      )
    );
  }
}
