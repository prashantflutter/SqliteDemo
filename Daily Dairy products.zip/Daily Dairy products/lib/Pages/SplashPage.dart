import 'dart:async';

import 'package:flutter/material.dart';

import 'LoginPage.dart';


class SplashPage extends StatefulWidget {
  const SplashPage({super.key});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  
  @override
  void initState() {
    super.initState();
    Timer(Duration(seconds: 2), ()=>Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=> LoginPage())));
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox(child: Image.asset('assets/splash.png')),
    );
  }
}
