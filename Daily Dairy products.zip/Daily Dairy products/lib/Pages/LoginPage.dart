import 'package:dailydairyproducts/Constant/AppColors.dart';
import 'package:dailydairyproducts/Pages/SignUpPage.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../MYWidgets/MyWidgets.dart';
import 'Homepage.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  bool isVisibility = true;
  ValueNotifier isValue = ValueNotifier<int>(0);
  
  void login()async{
    String email = emailController.text.trim();
    String password = passwordController.text.trim();
    if(email.isEmpty || password.isEmpty){
      MyDialog(context: context, title: 'Please fill email and password!');
    }else{
      try{
        UserCredential userCredential = await FirebaseAuth.instance.signInWithEmailAndPassword(email: email, password: password);
        if(userCredential.user != null){
          MyDialog(context: context, title: 'Successfully login...',backgroundColor: pGreen,icon: Icons.done);
          Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=> Homepage()));
        }
      }on FirebaseAuthException catch(ex){
        MyDialog(context: context, title: ex.code.toString());
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final size  = MediaQuery.of(context).size;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Container(
        width: size.width,
        height: size.height,
        decoration: BoxDecoration(
            image: DecorationImage(image: AssetImage('assets/bg.png'),fit: BoxFit.cover)
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            MyTextForm(context: context,
              controller: emailController,
              hintText: 'Enter Email',
            ),
            SizedBox(height: 15,),
            MyTextForm(context: context,
                controller: passwordController,
                hintText: 'Enter Password',
                suffixIcon: ValueListenableBuilder(
                    valueListenable: isValue,
                    builder: (context,value,child) {
                      return IconButton(onPressed: (){
                        isVisibility = !isVisibility;
                        isValue.value ++;
                      }, icon: Icon(isVisibility?Icons.visibility:Icons.visibility_off_outlined,color: pBlue,));
                    }
                )
            ),
            MyButton(context: context, title: 'Login', onPressed: (){
              login();
            }),
            MyTextButton(title: 'don\'t have an account? Sign up', onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=> SignupPage()),),)
          ],
        ),
      ),
    );
  }
}





