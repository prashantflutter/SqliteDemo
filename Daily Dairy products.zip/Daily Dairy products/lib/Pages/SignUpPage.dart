import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dailydairyproducts/Constant/AppColors.dart';
import 'package:dailydairyproducts/Pages/LoginPage.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../Constant/AppStyle.dart';
import '../MYWidgets/MyWidgets.dart';


class SignupPage extends StatefulWidget {
  const SignupPage({super.key});

  @override
  State<SignupPage> createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage> {

  TextEditingController fNameController = TextEditingController();
  TextEditingController lNamedController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController cPasswordController = TextEditingController();
  bool isVisibility = true;
  bool isCVisibility = true;
  ValueNotifier isValue = ValueNotifier<int>(0);

  void signUp()async{
    String fName = fNameController.text.trim();
    String lName = lNamedController.text.trim();
    String email = emailController.text.trim();
    String phoneNumber = phoneController.text.trim();
    String password = passwordController.text.trim();
    String cPassword = cPasswordController.text.trim();
    if(fName.isEmpty || lName.isEmpty || email.isEmpty || phoneNumber.isEmpty || cPassword.isEmpty || password.isEmpty){
      MyDialog(context: context, title: 'Please fill all Details!',);
    }else if(password != cPassword){
      MyDialog(context: context, title: 'Password do match!');
    }else{
      try{
        UserCredential userCredential =  await FirebaseAuth.instance.createUserWithEmailAndPassword(email: email, password: password);
        if(userCredential.user != null){
          Map<String,dynamic>userProfileData = {
            'firstName':fName,
            'lastName':lName,
            'email':email,
            'phoneNumber':phoneNumber,
          };
          FirebaseFirestore.instance.collection('userProfile').add(userProfileData);
          MyDialog(context: context, title: 'Successfully Register...',icon: Icons.download_done,backgroundColor: pGreen);
          Navigator.push(context, MaterialPageRoute(builder: (context)=> LoginPage()));
        }
      }on FirebaseAuthException catch(ex){
        MyDialog(context: context, title: ex.code.toString());
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final size  = MediaQuery.of(context).size;
    return SafeArea(
      top: true,
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: Container(
          width: size.width,
          height: size.height,
          padding:  EdgeInsets.symmetric(horizontal: 20),
          decoration: BoxDecoration(
            // image: DecorationImage(image: AssetImage('assets/bg.png'),fit: BoxFit.cover)
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 20),
                child: Text('Sign up',style: MyTextStyle(color: pBlue,fontSize: size.height*0.035),),
              ),
              Text('Get Your Daily Dairy Product Easily',style: MyTextStyle(color: pGrey,fontSize: size.height*0.016),),
              Expanded(
                child: ValueListenableBuilder(
                    valueListenable: isValue,
                    builder: (context,value,child) {
                      return Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              SizedBox(
                                width:size.width*0.43,
                                child: MyRowTextForm(context: context,
                                  controller: fNameController,
                                  hintText: 'First Name',
                                ),
                              ),
                              SizedBox(
                                width:size.width*0.43,
                                child: MyRowTextForm(context: context,
                                  controller: lNamedController,
                                  hintText: 'Last Name',
                                ),
                              ),

                            ],
                          ),
                          MyRowTextForm(context: context, controller: emailController, hintText: 'Email'),
                          MyRowTextForm(context: context, controller: phoneController, hintText: 'Mobile',maxLength: 10,keyboardType: TextInputType.phone),
                          MyRowTextForm(context: context, controller: passwordController, hintText: 'Password',obscureText:isVisibility,
                            suffixIcon: IconButton(onPressed: (){
                              isVisibility = !isVisibility;
                              isValue.value++;
                            }, icon: Icon(isVisibility?Icons.visibility:Icons.visibility_off,color: pBlue,),),),
                          MyRowTextForm(context: context, controller: cPasswordController, hintText: 'Confirm Password',
                                obscureText:isCVisibility,
                              suffixIcon: IconButton(onPressed: (){
                                isCVisibility = !isCVisibility;
                                isValue.value++;
                              }, icon: Icon(isCVisibility?Icons.visibility:Icons.visibility_off,color: pBlue,),)),
                          MyButton(context: context, title: "Resister",
                              onPressed: (){
                              signUp();
                          }),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: MyTextButton(title: 'Already have an account? Log In', onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=> LoginPage()),),),
                          )

                        ],
                      );
                    }
                ),
              ),

            ],
          ),
        ),
      ),
    );
  }
}


