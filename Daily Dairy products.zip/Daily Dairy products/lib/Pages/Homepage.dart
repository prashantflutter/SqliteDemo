import 'package:dailydairyproducts/Constant/AppColors.dart';
import 'package:dailydairyproducts/Constant/AppStyle.dart';
import 'package:dailydairyproducts/TabPAGES/CheeseProductPage.dart';
import 'package:dailydairyproducts/TabPAGES/MilkProductPage.dart';
import 'package:flutter/material.dart';

import '../TabPAGES/ButterProductPage.dart';
import '../TabPAGES/PaneerProductPage.dart';

class Homepage extends StatefulWidget {
  const Homepage({super.key});

  @override
  State<Homepage> createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return DefaultTabController(
      initialIndex: 0,
      length: 4,
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          centerTitle: true,
          title: Text('Daily Dairy',style: MyTextStyle(color: pBlue,fontSize: size.height*0.023,fontWeight: FontWeight.bold),),
        ),
        body: Column(
          children: [
            Row(
              children: [
                SizedBox(width: 20,),
                Text('Categories',style: MyTextStyle(color: pBlack,fontSize: size.height*0.045,),),
              ],
            ),
            TabBar(
              indicatorSize: TabBarIndicatorSize.tab,
                tabs: [
              Tab(
                text: 'Milk',
              ),
              Tab(
                text: 'Cheese',
              ),
              Tab(
                text: 'Paneer',
              ),
              Tab(
                text: 'Butter',
              ),
            ]),
            Expanded(
              child: TabBarView(children: [
                MilkProductPage(),
                CheeseProductPage(),
                PaneerProductPage(),
                ButterProductPage(),
              ]),
            ),
      
          ],
        ),
      ),
    );
  }
}
